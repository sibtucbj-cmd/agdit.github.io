package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.DanaCitaDatabase
import com.example.data.repository.LoanRepository
import com.example.ui.components.DanaCitaBottomNavigation
import com.example.ui.components.DanaCitaTopBar
import com.example.ui.screens.BillsScreen
import com.example.ui.screens.FastVerificationScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoanApplicationScreen
import com.example.ui.screens.LoanCalculatorScreen
import com.example.ui.screens.PartnersScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RegistrationScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.LoanViewModelFactory
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val coroutineScope = rememberCoroutineScope()
        val database = remember { DanaCitaDatabase.getDatabase(applicationContext, coroutineScope) }
        val repository = remember {
          LoanRepository(
            userDao = database.userDao(),
            loanDao = database.loanDao(),
            installmentDao = database.installmentDao()
          )
        }
        val viewModel: LoanViewModel = viewModel(
          factory = LoanViewModelFactory(repository)
        )

        DanaCitaApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun DanaCitaApp(
  viewModel: LoanViewModel,
  modifier: Modifier = Modifier
) {
  val currentScreen by viewModel.currentScreen.collectAsState()
  val unpaidBills by viewModel.unpaidBills.collectAsState()
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(Unit) {
    viewModel.userMessage.collectLatest { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  // Handle back button when on sub-screens
  BackHandler(enabled = currentScreen != Screen.Home) {
    viewModel.navigateTo(Screen.Home)
  }

  val isSubScreen = currentScreen == Screen.FastVerification || currentScreen == Screen.LoanApply || currentScreen == Screen.Register

  Scaffold(
    topBar = {
      if (!isSubScreen) {
        DanaCitaTopBar(
          currentScreen = currentScreen,
          onProfileClick = { viewModel.navigateTo(Screen.Profile) }
        )
      }
    },
    bottomBar = {
      if (!isSubScreen) {
        DanaCitaBottomNavigation(
          currentScreen = currentScreen,
          onSelectScreen = { viewModel.navigateTo(it) },
          unpaidCount = unpaidBills.size
        )
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
      ) { targetScreen ->
        when (targetScreen) {
          Screen.Home -> HomeScreen(
            viewModel = viewModel,
            onNavigateToScreen = { viewModel.navigateTo(it) }
          )

          Screen.Register -> RegistrationScreen(
            viewModel = viewModel,
            onNavigateBack = { viewModel.navigateTo(Screen.Home) },
            onProceedToVerification = { viewModel.navigateTo(Screen.FastVerification) },
            onProceedToLoanApply = { viewModel.navigateTo(Screen.LoanApply) }
          )

          Screen.Calculator -> LoanCalculatorScreen(
            viewModel = viewModel,
            onProceedToApply = { viewModel.navigateTo(Screen.LoanApply) }
          )

          Screen.FastVerification -> FastVerificationScreen(
            viewModel = viewModel,
            onNavigateBack = { viewModel.navigateTo(Screen.Home) }
          )

          Screen.LoanApply -> LoanApplicationScreen(
            viewModel = viewModel,
            onNavigateBack = { viewModel.navigateTo(Screen.Home) },
            onSuccessSubmitted = { viewModel.navigateTo(Screen.Bills) }
          )

          Screen.Bills -> BillsScreen(
            viewModel = viewModel
          )

          Screen.Partners -> PartnersScreen(
            viewModel = viewModel,
            onSelectPartner = { viewModel.navigateTo(Screen.LoanApply) }
          )

          Screen.Profile -> ProfileScreen(
            viewModel = viewModel,
            onNavigateToScreen = { viewModel.navigateTo(it) }
          )
        }
      }
    }
  }
}
