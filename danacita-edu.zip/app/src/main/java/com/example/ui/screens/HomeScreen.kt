package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PartnerData
import com.example.data.model.VerificationStatus
import com.example.ui.components.OjkComplianceFooter
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun HomeScreen(
  viewModel: LoanViewModel,
  onNavigateToScreen: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val activeLoans by viewModel.activeLoans.collectAsState()
  val unpaidBills by viewModel.unpaidBills.collectAsState()
  val scrollState = rememberScrollState()

  val isVerified = userProfile?.verificationStatus == VerificationStatus.VERIFIED.name
  val nextBill = unpaidBills.firstOrNull()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Greeting & Verification Badge
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column {
        Text(
          text = "Halo, ${userProfile?.fullName?.split(" ")?.firstOrNull() ?: "Mahasiswa"}!",
          style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.Bold,
            color = DanaBluePrimary
          )
        )
        Text(
          text = userProfile?.universityName ?: "Universitas Indonesia",
          style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
        )
      }

      if (isVerified) {
        StatusPill(
          text = "Akun Terverifikasi",
          color = DanaSuccess,
          backgroundColor = DanaSuccessContainer,
          icon = Icons.Default.Verified
        )
      } else {
        StatusPill(
          text = "Belum Terverifikasi",
          color = Color(0xFFD97706),
          backgroundColor = Color(0xFFFEF3C7),
          icon = Icons.Default.Warning
        )
      }
    }

    // Limit Card / Credit Available
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .background(
          Brush.linearGradient(
            colors = listOf(DanaBluePrimary, DanaBlueDark)
          )
        )
        .padding(20.dp)
        .testTag("home_limit_card")
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Payments,
              contentDescription = null,
              tint = DanaGold,
              modifier = Modifier.size(18.dp)
            )
            Text(
              text = "Plafon Dana Pendidikan Tersedia",
              color = Color.White.copy(alpha = 0.9f),
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color.White.copy(alpha = 0.15f))
              .padding(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text(
              text = if (isVerified) "Skor: ${userProfile?.creditScore ?: 820}" else "Perlu Verifikasi",
              color = if (isVerified) Color(0xFF34D399) else DanaGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Text(
          text = if (isVerified) formatRupiah(userProfile?.availableLimit ?: 23_000_000L) else "Rp 0",
          color = Color.White,
          style = MaterialTheme.typography.displayLarge.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 30.sp
          )
        )

        val totalLimit = userProfile?.approvedLimit ?: 35_000_000L
        val available = userProfile?.availableLimit ?: 23_000_000L
        val ratio = if (totalLimit > 0) available.toFloat() / totalLimit else 0f

        LinearProgressIndicator(
          progress = { ratio },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = DanaGold,
          trackColor = Color.White.copy(alpha = 0.2f)
        )

        Row(
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Total Plafon Disetujui: ${formatRupiah(totalLimit)}",
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 11.sp
          )
          Text(
            text = "Bunga 0% DP",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    // New Borrower Registration Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
      border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
      modifier = Modifier
        .fillMaxWidth()
        .clickable { onNavigateToScreen(Screen.Register) }
        .testTag("banner_register_borrower")
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(14.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF16A34A))
        ) {
          Icon(
            imageVector = Icons.Default.PersonAdd,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = "Pendaftaran Peminjam Baru",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color(0xFF166534)
              )
            )
            StatusPill(
              text = "Promo 0%",
              color = Color(0xFF166534),
              backgroundColor = Color(0xFFDCFCE7)
            )
          }
          Text(
            text = "Daftar akun peminjam mahasiswa/wali untuk aktifkan pembiayaan dan diskon biaya layanan.",
            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF15803D))
          )
        }

        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = Color(0xFF166534)
        )
      }
    }

    // Fast Verification Prompt Banner (if not verified or quick CTA)
    if (!isVerified) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToScreen(Screen.FastVerification) }
          .testTag("banner_verify_fast_cta")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.padding(14.dp)
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(DanaBluePrimary)
          ) {
            Icon(
              imageVector = Icons.Default.Speed,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Verifikasi Kilat 2 Menit",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
            Text(
              text = "Lengkapi data KTP & selfie wajah untuk buka limit s/d Rp 40 Juta secara instan.",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
          }

          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = DanaBluePrimary
          )
        }
      }
    }

    // Quick Action Grid - 2 Rows
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        QuickActionCard(
          title = "Ajukan Baru",
          subtitle = "Pencairan",
          icon = Icons.Default.Add,
          color = DanaBluePrimary,
          containerColor = DanaBlueContainer,
          modifier = Modifier
            .weight(1f)
            .testTag("action_apply_loan"),
          onClick = { onNavigateToScreen(Screen.LoanApply) }
        )

        QuickActionCard(
          title = "Daftar Akun",
          subtitle = "Peminjam",
          icon = Icons.Default.PersonAdd,
          color = Color(0xFF16A34A),
          containerColor = Color(0xFFDCFCE7),
          modifier = Modifier
            .weight(1f)
            .testTag("action_register_borrower"),
          onClick = { onNavigateToScreen(Screen.Register) }
        )

        QuickActionCard(
          title = "Simulasi",
          subtitle = "Cek Cicilan",
          icon = Icons.Default.Calculate,
          color = Color(0xFF0D9488),
          containerColor = Color(0xFFCCFBF1),
          modifier = Modifier
            .weight(1f)
            .testTag("action_simulation"),
          onClick = { onNavigateToScreen(Screen.Calculator) }
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        QuickActionCard(
          title = "Verifikasi Kilat",
          subtitle = "Selfie & KTP 2 Menit",
          icon = Icons.Default.Speed,
          color = Color(0xFFE11D48),
          containerColor = Color(0xFFFFE4E6),
          modifier = Modifier
            .weight(1f)
            .testTag("action_verify"),
          onClick = { onNavigateToScreen(Screen.FastVerification) }
        )

        QuickActionCard(
          title = "Mitra Kampus & IT",
          subtitle = "UI, ITB, Hacktiv8, BINUS",
          icon = Icons.Default.School,
          color = Color(0xFFD97706),
          containerColor = Color(0xFFFEF3C7),
          modifier = Modifier
            .weight(1f)
            .testTag("action_partners"),
          onClick = { onNavigateToScreen(Screen.Partners) }
        )
      }
    }

    // Hero Visual Banner (Generated asset)
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column {
        Image(
          painter = painterResource(id = R.drawable.banner_dana_edu_1793994717282),
          contentDescription = "Pembiayaan Pendidikan DanaCita",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp)
        ) {
          Column {
            Text(
              text = "Pembiayaan Kuliah 0% DP",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "Langsung dibayarkan ke universitas / bootcamp mitra",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
          }

          Button(
            onClick = { onNavigateToScreen(Screen.LoanApply) },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary)
          ) {
            Text("Ajukan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Upcoming Bill Card (if exists)
    if (nextBill != null) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFFED7AA)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEF3C7))
              ) {
                Icon(
                  imageVector = Icons.Default.CreditCard,
                  contentDescription = null,
                  tint = DanaGold,
                  modifier = Modifier.size(18.dp)
                )
              }
              Column {
                Text(
                  text = "Tagihan Bulan Ini",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "Cicilan ke-${nextBill.billNumber} dari ${nextBill.totalBills}",
                  style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
                )
              }
            }

            StatusPill(
              text = "Jatuh Tempo: ${nextBill.dueDate}",
              color = Color(0xFFD97706),
              backgroundColor = Color(0xFFFEF3C7)
            )
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column {
              Text(
                text = "Nominal Angsuran",
                style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary)
              )
              Text(
                text = formatRupiah(nextBill.amount),
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = DanaBluePrimary
                )
              )
            }

            Button(
              onClick = {
                viewModel.selectBillForPayment(nextBill)
                onNavigateToScreen(Screen.Bills)
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
              modifier = Modifier.testTag("home_pay_bill_button")
            ) {
              Text("Bayar Sekarang", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }

    // Featured Partners Carousel
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = "Mitra Pendidikan Terverifikasi",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "Lihat Semua",
          color = DanaBluePrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.clickable { onNavigateToScreen(Screen.Partners) }
        )
      }

      LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(PartnerData.partners) { partner ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, DanaOutline),
            modifier = Modifier
              .width(220.dp)
              .clickable {
                viewModel.selectPartner(partner)
                onNavigateToScreen(Screen.LoanApply)
              }
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
              ) {
                Box(
                  contentAlignment = Alignment.Center,
                  modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(partner.colorHex).copy(alpha = 0.15f))
                ) {
                  Text(
                    text = partner.name.take(2).uppercase(),
                    color = Color(partner.colorHex),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                  )
                }

                StatusPill(
                  text = partner.badgeText,
                  color = DanaBluePrimary,
                  backgroundColor = DanaBlueContainer
                )
              }

              Text(
                text = partner.name,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1
              )

              Text(
                text = partner.programs,
                style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary),
                maxLines = 2
              )

              Text(
                text = partner.feeDescription,
                style = MaterialTheme.typography.labelSmall.copy(
                  color = DanaSuccess,
                  fontWeight = FontWeight.SemiBold
                )
              )
            }
          }
        }
      }
    }

    OjkComplianceFooter()
  }
}

@Composable
fun QuickActionCard(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  containerColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, DanaOutline),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier.clickable { onClick() }
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(4.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp, horizontal = 4.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(containerColor)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = color,
          modifier = Modifier.size(20.dp)
        )
      }
      Text(
        text = title,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = DanaTextSecondary)
      )
    }
  }
}
