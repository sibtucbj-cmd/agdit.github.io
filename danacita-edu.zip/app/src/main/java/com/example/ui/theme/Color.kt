package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DanaCita Brand Colors - Fintech & Education Blue Theme
val DanaBluePrimary = Color(0xFF0F4C81)
val DanaBlueDark = Color(0xFF082D52)
val DanaBlueLight = Color(0xFF1E6FBA)
val DanaBlueContainer = Color(0xFFE3F2FD)
val DanaOnBlueContainer = Color(0xFF0D3B66)

// Accent and Secondary
val DanaTeal = Color(0xFF0D9488)
val DanaTealContainer = Color(0xFFCCFBF1)
val DanaGold = Color(0xFFF59E0B)
val DanaGoldContainer = Color(0xFFFEF3C7)

// Neutral surfaces
val DanaBackground = Color(0xFFF8FAFC)
val DanaSurface = Color(0xFFFFFFFF)
val DanaSurfaceVariant = Color(0xFFF1F5F9)
val DanaOutline = Color(0xFFE2E8F0)
val DanaOutlineVariant = Color(0xFFCBD5E1)

// Semantic status colors
val DanaSuccess = Color(0xFF10B981)
val DanaSuccessContainer = Color(0xFFD1FAE5)
val DanaWarning = Color(0xFFF59E0B)
val DanaError = Color(0xFFEF4444)
val DanaErrorContainer = Color(0xFFFEE2E2)

// Text colors
val DanaTextPrimary = Color(0xFF0F172A)
val DanaTextSecondary = Color(0xFF475569)
val DanaTextTertiary = Color(0xFF94A3B8)
