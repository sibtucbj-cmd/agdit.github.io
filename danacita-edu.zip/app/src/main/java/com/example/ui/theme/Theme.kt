package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = DanaBlueLight,
  onPrimary = Color.White,
  primaryContainer = DanaBlueDark,
  onPrimaryContainer = DanaBlueContainer,
  secondary = DanaTeal,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFF134E48),
  onSecondaryContainer = DanaTealContainer,
  tertiary = DanaGold,
  background = Color(0xFF0F172A),
  surface = Color(0xFF1E293B),
  surfaceVariant = Color(0xFF334155),
  onBackground = Color(0xFFF8FAFC),
  onSurface = Color(0xFFF8FAFC),
  outline = Color(0xFF475569)
)

private val LightColorScheme = lightColorScheme(
  primary = DanaBluePrimary,
  onPrimary = Color.White,
  primaryContainer = DanaBlueContainer,
  onPrimaryContainer = DanaOnBlueContainer,
  secondary = DanaTeal,
  onSecondary = Color.White,
  secondaryContainer = DanaTealContainer,
  onSecondaryContainer = Color(0xFF134E48),
  tertiary = DanaGold,
  onTertiary = Color.White,
  background = DanaBackground,
  surface = DanaSurface,
  surfaceVariant = DanaSurfaceVariant,
  onBackground = DanaTextPrimary,
  onSurface = DanaTextPrimary,
  outline = DanaOutline,
  outlineVariant = DanaOutlineVariant
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep consistent fintech brand identity
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    content = content
  )
}
