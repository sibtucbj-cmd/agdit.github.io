package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.InstallmentBill
import com.example.data.model.LoanApplication
import com.example.data.model.PartnerData
import com.example.data.model.PartnerInstitution
import com.example.data.model.UserProfile
import com.example.data.model.VerificationStatus
import com.example.data.repository.LoanRepository
import com.example.ui.util.LoanCalculationResult
import com.example.ui.util.calculateLoanDetails
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen(val title: String) {
  object Home : Screen("Beranda")
  object Register : Screen("Pendaftaran Peminjam")
  object Calculator : Screen("Simulasi")
  object FastVerification : Screen("Verifikasi Kilat")
  object LoanApply : Screen("Ajukan Pinjaman")
  object Bills : Screen("Tagihan")
  object Partners : Screen("Mitra Kampus")
  object Profile : Screen("Profil")
}

data class RegistrationFormState(
  val role: String = "Mahasiswa", // "Mahasiswa", "Orang Tua / Wali", "Siswa Bootcamp"
  val fullName: String = "",
  val phoneNumber: String = "",
  val email: String = "",
  val passwordPin: String = "",
  val confirmPasswordPin: String = "",
  val targetCampus: String = "Universitas Indonesia (UI)",
  val referralCode: String = "",
  val agreedToTerms: Boolean = true,
  val isOtpSent: Boolean = false,
  val otpCode: String = "",
  val simulatedSentOtp: String = "8492",
  val otpCountdown: Int = 60,
  val isLoading: Boolean = false,
  val isRegisteredSuccess: Boolean = false,
  val registeredUserId: String = "DC-" + (10000..99999).random()
)

data class VerificationFormState(
  val currentStep: Int = 1, // 1: KTP, 2: Face Liveness, 3: Education, 4: Bank, 5: Result
  val fullName: String = "Budi Santoso",
  val nik: String = "3201123456780001",
  val email: String = "budi.santoso@mahasiswa.ac.id",
  val phone: String = "081234567890",
  val dob: String = "15 Mei 2002",
  val address: String = "Jl. Margonda Raya No. 45, Depok",
  val faceVerified: Boolean = false,
  val faceScanProgress: Float = 0f,
  val isScanningFace: Boolean = false,
  val university: String = "Universitas Indonesia",
  val major: String = "Teknik Informatika (S1)",
  val studentId: String = "2006123456",
  val bankName: String = "BCA (Bank Central Asia)",
  val bankAccount: String = "5271928371",
  val bankHolder: String = "Budi Santoso",
  val emergencyName: String = "Agus Santoso",
  val emergencyPhone: String = "081398765432",
  val emergencyRelation: String = "Orang Tua / Wali",
  val isSubmitting: Boolean = false,
  val isCompleted: Boolean = false,
  val generatedScore: Int = 835,
  val generatedLimit: Long = 35_000_000L
)

class LoanViewModel(
  private val repository: LoanRepository
) : ViewModel() {

  private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
  val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

  val userProfile: StateFlow<UserProfile?> = repository.userProfileFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = null
  )

  val allLoans: StateFlow<List<LoanApplication>> = repository.allLoansFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val activeLoans: StateFlow<List<LoanApplication>> = repository.activeLoansFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val unpaidBills: StateFlow<List<InstallmentBill>> = repository.unpaidBillsFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val allBills: StateFlow<List<InstallmentBill>> = repository.allBillsFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  // Simulation State
  private val _simAmount = MutableStateFlow(12_000_000L)
  val simAmount: StateFlow<Long> = _simAmount.asStateFlow()

  private val _simTenor = MutableStateFlow(6)
  val simTenor: StateFlow<Int> = _simTenor.asStateFlow()

  private val _simPurpose = MutableStateFlow("Biaya SPP / UKT Kuliah")
  val simPurpose: StateFlow<String> = _simPurpose.asStateFlow()

  private val _selectedPartner = MutableStateFlow<PartnerInstitution?>(PartnerData.partners.first())
  val selectedPartner: StateFlow<PartnerInstitution?> = _selectedPartner.asStateFlow()

  // Registration Form State
  private val _registrationState = MutableStateFlow(RegistrationFormState())
  val registrationState: StateFlow<RegistrationFormState> = _registrationState.asStateFlow()

  // Verification Form State
  private val _verificationState = MutableStateFlow(VerificationFormState())
  val verificationState: StateFlow<VerificationFormState> = _verificationState.asStateFlow()

  // Payment Feedback Toast/Message
  private val _userMessage = MutableSharedFlow<String>()
  val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

  // Selected Bill to Pay
  private val _selectedBillForPayment = MutableStateFlow<InstallmentBill?>(null)
  val selectedBillForPayment: StateFlow<InstallmentBill?> = _selectedBillForPayment.asStateFlow()

  fun navigateTo(screen: Screen) {
    _currentScreen.value = screen
  }

  // Registration Actions
  fun updateRegistrationRole(role: String) {
    _registrationState.value = _registrationState.value.copy(role = role)
  }

  fun updateRegistrationField(
    fullName: String? = null,
    phoneNumber: String? = null,
    email: String? = null,
    passwordPin: String? = null,
    confirmPasswordPin: String? = null,
    targetCampus: String? = null,
    referralCode: String? = null,
    agreedToTerms: Boolean? = null
  ) {
    val current = _registrationState.value
    _registrationState.value = current.copy(
      fullName = fullName ?: current.fullName,
      phoneNumber = phoneNumber ?: current.phoneNumber,
      email = email ?: current.email,
      passwordPin = passwordPin ?: current.passwordPin,
      confirmPasswordPin = confirmPasswordPin ?: current.confirmPasswordPin,
      targetCampus = targetCampus ?: current.targetCampus,
      referralCode = referralCode ?: current.referralCode,
      agreedToTerms = agreedToTerms ?: current.agreedToTerms
    )
  }

  fun sendRegistrationOtp() {
    viewModelScope.launch {
      val state = _registrationState.value
      if (state.fullName.isBlank() || state.phoneNumber.isBlank()) {
        _userMessage.emit("Mohon lengkapi Nama Lengkap dan No. WhatsApp!")
        return@launch
      }
      _registrationState.value = state.copy(isLoading = true)
      delay(800)
      _registrationState.value = state.copy(
        isLoading = false,
        isOtpSent = true,
        simulatedSentOtp = "8492"
      )
      _userMessage.emit("Kode OTP 8492 telah dikirimkan via WhatsApp ke ${state.phoneNumber}")
    }
  }

  fun updateOtpCode(code: String) {
    _registrationState.value = _registrationState.value.copy(otpCode = code)
  }

  fun autoFillOtp() {
    _registrationState.value = _registrationState.value.copy(otpCode = _registrationState.value.simulatedSentOtp)
  }

  fun submitRegistration(onSuccess: () -> Unit) {
    viewModelScope.launch {
      val state = _registrationState.value
      if (state.otpCode != state.simulatedSentOtp) {
        _userMessage.emit("Kode OTP salah! Masukkan kode OTP yang benar (8492).")
        return@launch
      }
      _registrationState.value = state.copy(isLoading = true)
      delay(900)

      val profile = repository.registerNewBorrower(
        fullName = state.fullName,
        email = state.email,
        phoneNumber = state.phoneNumber,
        borrowerRole = state.role,
        universityName = state.targetCampus,
        referralCode = state.referralCode
      )

      // Also prefill verification state with registered information
      _verificationState.value = _verificationState.value.copy(
        fullName = profile.fullName,
        email = profile.email,
        phone = profile.phoneNumber,
        university = profile.universityName
      )

      _registrationState.value = state.copy(
        isLoading = false,
        isRegisteredSuccess = true
      )
      _userMessage.emit("Pendaftaran Berhasil! Akun peminjam ${profile.fullName} telah aktif.")
      onSuccess()
    }
  }

  fun resetRegistrationForm() {
    _registrationState.value = RegistrationFormState()
  }

  fun updateSimAmount(amount: Long) {
    _simAmount.value = amount
  }

  fun updateSimTenor(tenor: Int) {
    _simTenor.value = tenor
  }

  fun updateSimPurpose(purpose: String) {
    _simPurpose.value = purpose
  }

  fun selectPartner(partner: PartnerInstitution) {
    _selectedPartner.value = partner
  }

  fun getSimulationDetails(): LoanCalculationResult {
    return calculateLoanDetails(_simAmount.value, _simTenor.value)
  }

  // Fast Verification Actions
  fun updateVerificationStep(step: Int) {
    _verificationState.value = _verificationState.value.copy(currentStep = step)
  }

  fun updateVerificationField(
    fullName: String? = null,
    nik: String? = null,
    email: String? = null,
    phone: String? = null,
    dob: String? = null,
    address: String? = null,
    university: String? = null,
    major: String? = null,
    studentId: String? = null,
    bankName: String? = null,
    bankAccount: String? = null,
    bankHolder: String? = null,
    emergencyName: String? = null,
    emergencyPhone: String? = null,
    emergencyRelation: String? = null
  ) {
    val current = _verificationState.value
    _verificationState.value = current.copy(
      fullName = fullName ?: current.fullName,
      nik = nik ?: current.nik,
      email = email ?: current.email,
      phone = phone ?: current.phone,
      dob = dob ?: current.dob,
      address = address ?: current.address,
      university = university ?: current.university,
      major = major ?: current.major,
      studentId = studentId ?: current.studentId,
      bankName = bankName ?: current.bankName,
      bankAccount = bankAccount ?: current.bankAccount,
      bankHolder = bankHolder ?: current.bankHolder,
      emergencyName = emergencyName ?: current.emergencyName,
      emergencyPhone = emergencyPhone ?: current.emergencyPhone,
      emergencyRelation = emergencyRelation ?: current.emergencyRelation
    )
  }

  fun startFaceLivenessScan() {
    viewModelScope.launch {
      _verificationState.value = _verificationState.value.copy(
        isScanningFace = true,
        faceScanProgress = 0.1f
      )
      delay(400)
      _verificationState.value = _verificationState.value.copy(faceScanProgress = 0.45f)
      delay(500)
      _verificationState.value = _verificationState.value.copy(faceScanProgress = 0.85f)
      delay(500)
      _verificationState.value = _verificationState.value.copy(
        faceScanProgress = 1.0f,
        isScanningFace = false,
        faceVerified = true
      )
      _userMessage.emit("Verifikasi Wajah Berhasil: Wajah 99.8% Cocok dengan KTP!")
    }
  }

  fun submitFastVerification() {
    viewModelScope.launch {
      val state = _verificationState.value
      _verificationState.value = state.copy(isSubmitting = true)
      delay(1200) // Fast instant evaluation simulation

      val profile = repository.completeFastVerification(
        fullName = state.fullName,
        nik = state.nik,
        email = state.email,
        phone = state.phone,
        dob = state.dob,
        address = state.address,
        university = state.university,
        major = state.major,
        studentId = state.studentId,
        bankName = state.bankName,
        bankAccount = state.bankAccount,
        bankHolder = state.bankHolder,
        emergencyName = state.emergencyName,
        emergencyPhone = state.emergencyPhone,
        emergencyRelation = state.emergencyRelation
      )

      _verificationState.value = state.copy(
        isSubmitting = false,
        isCompleted = true,
        currentStep = 5,
        generatedScore = profile.creditScore,
        generatedLimit = profile.approvedLimit
      )
      _userMessage.emit("Selamat! Verifikasi Kilat Disetujui dengan Limit Rp 40.000.000!")
    }
  }

  // Loan Application Actions
  fun submitLoanApplication(
    purpose: String,
    institution: String,
    amount: Long,
    tenor: Int,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      repository.submitLoanApplication(
        purpose = purpose,
        institutionName = institution,
        amount = amount,
        tenorMonths = tenor
      )
      _userMessage.emit("Pengajuan Pembiayaan Disetujui & Berhasil Dicairkan ke Rekening Institusi!")
      onSuccess()
    }
  }

  // Payment Actions
  fun selectBillForPayment(bill: InstallmentBill?) {
    _selectedBillForPayment.value = bill
  }

  fun payBill(billId: String, method: String) {
    viewModelScope.launch {
      repository.payInstallment(billId, method)
      _selectedBillForPayment.value = null
      _userMessage.emit("Pembayaran Berhasil! Bukti transaksi telah diterbitkan.")
    }
  }

  fun resetVerificationForDemo() {
    viewModelScope.launch {
      repository.resetVerificationForDemo()
      _verificationState.value = VerificationFormState(
        currentStep = 1,
        faceVerified = false,
        faceScanProgress = 0f,
        isCompleted = false
      )
      _userMessage.emit("Akun direset ke Belum Terverifikasi untuk simulasi verifikasi kilat.")
    }
  }
}

class LoanViewModelFactory(private val repository: LoanRepository) : ViewModelProvider.Factory {
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    if (modelClass.isAssignableFrom(LoanViewModel::class.java)) {
      @Suppress("UNCHECKED_CAST")
      return LoanViewModel(repository) as T
    }
    throw IllegalArgumentException("Unknown ViewModel class")
  }
}
