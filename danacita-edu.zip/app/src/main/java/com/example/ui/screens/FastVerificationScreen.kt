package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PartnerData
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun FastVerificationScreen(
  viewModel: LoanViewModel,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val verificationState by viewModel.verificationState.collectAsState()
  val scrollState = rememberScrollState()

  BackHandler {
    if (verificationState.currentStep > 1 && verificationState.currentStep < 5) {
      viewModel.updateVerificationStep(verificationState.currentStep - 1)
    } else {
      onNavigateBack()
    }
  }

  Scaffold(
    topBar = {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
          IconButton(
            onClick = {
              if (verificationState.currentStep > 1 && verificationState.currentStep < 5) {
                viewModel.updateVerificationStep(verificationState.currentStep - 1)
              } else {
                onNavigateBack()
              }
            },
            modifier = Modifier.testTag("verify_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Kembali",
              tint = DanaBluePrimary
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Verifikasi Kilat DanaCita",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
            Text(
              text = if (verificationState.currentStep == 5) "Hasil Penilaian Kredit" else "Langkah ${verificationState.currentStep} dari 4",
              style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary)
            )
          }

          StatusPill(
            text = "Proses 2 Menit",
            color = DanaBluePrimary,
            backgroundColor = DanaBlueContainer,
            icon = Icons.Default.Speed
          )
        }
      }
    },
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (verificationState.currentStep < 5) {
        // Step progress header
        StepProgressBar(currentStep = verificationState.currentStep)
      }

      when (verificationState.currentStep) {
        1 -> Step1KtpData(
          state = verificationState,
          onFieldChange = { fn, nik, em, ph, dob, addr ->
            viewModel.updateVerificationField(
              fullName = fn,
              nik = nik,
              email = em,
              phone = ph,
              dob = dob,
              address = addr
            )
          },
          onNext = { viewModel.updateVerificationStep(2) }
        )

        2 -> Step2FaceLiveness(
          state = verificationState,
          onStartScan = { viewModel.startFaceLivenessScan() },
          onNext = { viewModel.updateVerificationStep(3) }
        )

        3 -> Step3EducationInfo(
          state = verificationState,
          onFieldChange = { univ, maj, nim ->
            viewModel.updateVerificationField(
              university = univ,
              major = maj,
              studentId = nim
            )
          },
          onNext = { viewModel.updateVerificationStep(4) }
        )

        4 -> Step4BankAndEmergency(
          state = verificationState,
          onFieldChange = { bank, acc, holder, emgName, emgPhone, emgRel ->
            viewModel.updateVerificationField(
              bankName = bank,
              bankAccount = acc,
              bankHolder = holder,
              emergencyName = emgName,
              emergencyPhone = emgPhone,
              emergencyRelation = emgRel
            )
          },
          onSubmit = { viewModel.submitFastVerification() }
        )

        5 -> Step5VerificationResult(
          state = verificationState,
          onApplyLoan = { viewModel.navigateTo(Screen.LoanApply) },
          onBackToHome = { viewModel.navigateTo(Screen.Home) }
        )
      }
    }
  }
}

@Composable
fun StepProgressBar(currentStep: Int) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      val steps = listOf("Data KTP", "Wajah", "Pendidikan", "Rekening")
      steps.forEachIndexed { index, name ->
        val stepNum = index + 1
        val isActive = stepNum == currentStep
        val isPassed = stepNum < currentStep

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(
                when {
                  isPassed -> DanaSuccess
                  isActive -> DanaBluePrimary
                  else -> Color(0xFFE2E8F0)
                }
              )
          ) {
            if (isPassed) {
              Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
            } else {
              Text(
                text = "$stepNum",
                color = if (isActive) Color.White else DanaTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = name,
            fontSize = 10.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = if (isActive) DanaBluePrimary else DanaTextSecondary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    LinearProgressIndicator(
      progress = { currentStep / 4f },
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = DanaBluePrimary,
      trackColor = Color(0xFFE2E8F0),
    )
  }
}

// STEP 1: KTP DATA
@Composable
fun Step1KtpData(
  state: com.example.ui.viewmodel.VerificationFormState,
  onFieldChange: (String, String, String, String, String, String) -> Unit,
  onNext: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(DanaBlueContainer)
        ) {
          Icon(
            imageVector = Icons.Default.Badge,
            contentDescription = null,
            tint = DanaBluePrimary
          )
        }
        Column {
          Text(
            text = "Langkah 1: Identitas KTP",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "Verifikasi identitas resmi sesuai e-KTP Republik Indonesia",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }

      // KTP Document Box / OCR Preview Card
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(1.dp, DanaOutline),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = DanaSuccess,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = "Foto KTP Terbaca Otomatis",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = DanaSuccess
                )
              )
            }
            StatusPill(
              text = "OCR Valid",
              color = DanaSuccess,
              backgroundColor = DanaSuccessContainer
            )
          }

          Text(
            text = "Sistem OCR cerdas DanaCita telah mengekstrak data dari KTP Anda secara otomatis untuk proses kilat.",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }

      // Form inputs
      OutlinedTextField(
        value = state.nik,
        onValueChange = { onFieldChange(state.fullName, it, state.email, state.phone, state.dob, state.address) },
        label = { Text("Nomor Induk Kependudukan (NIK 16 Digit)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_nik"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.fullName,
        onValueChange = { onFieldChange(it, state.nik, state.email, state.phone, state.dob, state.address) },
        label = { Text("Nama Lengkap Sesuai KTP") },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_full_name"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = state.dob,
          onValueChange = { onFieldChange(state.fullName, state.nik, state.email, state.phone, it, state.address) },
          label = { Text("Tanggal Lahir") },
          singleLine = true,
          modifier = Modifier.weight(1f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = DanaBluePrimary,
            unfocusedBorderColor = DanaOutline
          )
        )
        OutlinedTextField(
          value = state.phone,
          onValueChange = { onFieldChange(state.fullName, state.nik, state.email, it, state.dob, state.address) },
          label = { Text("No. WhatsApp") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.weight(1f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = DanaBluePrimary,
            unfocusedBorderColor = DanaOutline
          )
        )
      }

      OutlinedTextField(
        value = state.email,
        onValueChange = { onFieldChange(state.fullName, state.nik, it, state.phone, state.dob, state.address) },
        label = { Text("Email Mahasiswa / Pribadi") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.address,
        onValueChange = { onFieldChange(state.fullName, state.nik, state.email, state.phone, state.dob, it) },
        label = { Text("Alamat Domisili Sekarang") },
        singleLine = false,
        maxLines = 2,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      Button(
        onClick = onNext,
        enabled = state.nik.isNotBlank() && state.fullName.isNotBlank(),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("button_step1_next")
      ) {
        Text("Lanjut ke Verifikasi Wajah", fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(6.dp))
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
      }
    }
  }
}

// STEP 2: FACE LIVENESS BIOMETRIC VERIFICATION
@Composable
fun Step2FaceLiveness(
  state: com.example.ui.viewmodel.VerificationFormState,
  onStartScan: () -> Unit,
  onNext: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val scanBorderAlpha by infiniteTransition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "scan_pulse"
  )

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(DanaBlueContainer)
        ) {
          Icon(
            imageVector = Icons.Default.Face,
            contentDescription = null,
            tint = DanaBluePrimary
          )
        }
        Column {
          Text(
            text = "Langkah 2: Verifikasi Wajah",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "Biometrik Kilat Anti-Fraud & Pencocokan Wajah KTP",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }

      // Face Scan Box with visual feedback
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF0F172A))
      ) {
        // Oval Frame
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(200.dp, 230.dp)
            .clip(RoundedCornerShape(100.dp))
            .border(
              width = 3.dp,
              color = when {
                state.faceVerified -> DanaSuccess
                state.isScanningFace -> DanaBluePrimary.copy(alpha = scanBorderAlpha)
                else -> Color.White.copy(alpha = 0.5f)
              },
              shape = RoundedCornerShape(100.dp)
            )
        ) {
          if (state.faceVerified) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Verified",
                tint = DanaSuccess,
                modifier = Modifier.size(60.dp)
              )
              Text(
                text = "Wajah Terverifikasi 100%",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
              Text(
                text = "Kesesuaian KTP: 99.8%",
                color = DanaSuccess,
                fontSize = 12.sp
              )
            }
          } else if (state.isScanningFace) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              CircularProgressIndicator(
                progress = { state.faceScanProgress },
                color = DanaBluePrimary,
                modifier = Modifier.size(54.dp),
                strokeWidth = 4.dp
              )
              Text(
                text = "Memindai Biometrik Wajah...",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
              )
              Text(
                text = "Tatap layar lurus & kedipkan mata",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
              )
            }
          } else {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.padding(16.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CameraAlt,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.size(44.dp)
              )
              Text(
                text = "Posisikan Wajah di Tengah Lingkaran",
                color = Color.White,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
              )
            }
          }
        }
      }

      // Visual instructions
      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.padding(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = DanaBluePrimary,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = "Data biometrik dienkripsi 256-bit dan hanya digunakan untuk validasi legal OJK.",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = DanaTextSecondary)
          )
        }
      }

      if (!state.faceVerified) {
        Button(
          onClick = onStartScan,
          enabled = !state.isScanningFace,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("button_start_face_scan")
        ) {
          Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (state.isScanningFace) "Sedang Memindai..." else "Mulai Pindai Wajah Kilat",
            fontWeight = FontWeight.Bold
          )
        }
      } else {
        Button(
          onClick = onNext,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = DanaSuccess),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("button_step2_next")
        ) {
          Text("Lanjut ke Data Pendidikan", fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.width(6.dp))
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
        }
      }
    }
  }
}

// STEP 3: EDUCATION INFORMATION
@Composable
fun Step3EducationInfo(
  state: com.example.ui.viewmodel.VerificationFormState,
  onFieldChange: (String, String, String) -> Unit,
  onNext: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(DanaBlueContainer)
        ) {
          Icon(
            imageVector = Icons.Default.School,
            contentDescription = null,
            tint = DanaBluePrimary
          )
        }
        Column {
          Text(
            text = "Langkah 3: Data Pendidikan",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "Pilih kampus atau institusi bootcamp tempat Anda belajar",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }

      Text(
        text = "Pilih Kampus / Mitra Kursus:",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      // Quick chips for top partners
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val topPartners = listOf(
          "Universitas Indonesia (UI)",
          "Institut Teknologi Bandung (ITB)",
          "Hacktiv8 Coding Bootcamp",
          "BINUS University",
          "Purwadhika Digital School"
        )

        topPartners.forEach { partner ->
          val isSelected = state.university == partner
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) DanaBlueContainer else Color(0xFFF8FAFC)
            ),
            border = BorderStroke(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) DanaBluePrimary else DanaOutline
            ),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onFieldChange(partner, state.major, state.studentId) }
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
              Text(
                text = partner,
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) DanaBluePrimary else DanaTextPrimary
                )
              )
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = DanaBluePrimary,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }

      OutlinedTextField(
        value = state.major,
        onValueChange = { onFieldChange(state.university, it, state.studentId) },
        label = { Text("Jurusan / Program Studi / Batch") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.studentId,
        onValueChange = { onFieldChange(state.university, state.major, it) },
        label = { Text("Nomor Induk Mahasiswa (NIM) / No. Peserta") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      // Upload tuition invoice simulation badge
      Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.padding(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.UploadFile,
            contentDescription = null,
            tint = DanaSuccess,
            modifier = Modifier.size(22.dp)
          )
          Column {
            Text(
              text = "Bukti Tagihan SPP Terhubung",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color(0xFF166534)
              )
            )
            Text(
              text = "Invoice semester disinkronkan langsung via portal akademik mitra.",
              style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF15803D))
            )
          }
        }
      }

      Button(
        onClick = onNext,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("button_step3_next")
      ) {
        Text("Lanjut ke Rekening & Penjamin", fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(6.dp))
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
      }
    }
  }
}

// STEP 4: BANK ACCOUNT & EMERGENCY CONTACT
@Composable
fun Step4BankAndEmergency(
  state: com.example.ui.viewmodel.VerificationFormState,
  onFieldChange: (String, String, String, String, String, String) -> Unit,
  onSubmit: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(DanaBlueContainer)
        ) {
          Icon(
            imageVector = Icons.Default.AccountBalance,
            contentDescription = null,
            tint = DanaBluePrimary
          )
        }
        Column {
          Text(
            text = "Langkah 4: Rekening & Penjamin",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "Pencairan dana dan kontak darurat penjamin mahasiswa",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }

      Text(
        text = "Rekening Bank Mahasiswa:",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      OutlinedTextField(
        value = state.bankName,
        onValueChange = { onFieldChange(it, state.bankAccount, state.bankHolder, state.emergencyName, state.emergencyPhone, state.emergencyRelation) },
        label = { Text("Nama Bank (misal: BCA, Mandiri, BRI)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.bankAccount,
        onValueChange = { onFieldChange(state.bankName, it, state.bankHolder, state.emergencyName, state.emergencyPhone, state.emergencyRelation) },
        label = { Text("Nomor Rekening") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.bankHolder,
        onValueChange = { onFieldChange(state.bankName, state.bankAccount, it, state.emergencyName, state.emergencyPhone, state.emergencyRelation) },
        label = { Text("Nama Pemilik Rekening Sesuai Buku Tabungan") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Kontak Penjamin / Darurat (Orang Tua / Wali):",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      OutlinedTextField(
        value = state.emergencyName,
        onValueChange = { onFieldChange(state.bankName, state.bankAccount, state.bankHolder, it, state.emergencyPhone, state.emergencyRelation) },
        label = { Text("Nama Penjamin / Orang Tua") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = state.emergencyRelation,
          onValueChange = { onFieldChange(state.bankName, state.bankAccount, state.bankHolder, state.emergencyName, state.emergencyPhone, it) },
          label = { Text("Hubungan") },
          singleLine = true,
          modifier = Modifier.weight(1f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = DanaBluePrimary,
            unfocusedBorderColor = DanaOutline
          )
        )

        OutlinedTextField(
          value = state.emergencyPhone,
          onValueChange = { onFieldChange(state.bankName, state.bankAccount, state.bankHolder, state.emergencyName, it, state.emergencyRelation) },
          label = { Text("No. HP Penjamin") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.weight(1.2f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = DanaBluePrimary,
            unfocusedBorderColor = DanaOutline
          )
        )
      }

      Button(
        onClick = onSubmit,
        enabled = !state.isSubmitting,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("button_submit_verification")
      ) {
        if (state.isSubmitting) {
          CircularProgressIndicator(
            color = Color.White,
            modifier = Modifier.size(24.dp),
            strokeWidth = 2.5.dp
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("Memproses Penilaian Kilat (< 30 dtk)...", fontWeight = FontWeight.Bold)
        } else {
          Icon(imageVector = Icons.Default.Speed, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Selesaikan & Evaluasi Kilat", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

// STEP 5: VERIFICATION RESULT
@Composable
fun Step5VerificationResult(
  state: com.example.ui.viewmodel.VerificationFormState,
  onApplyLoan: () -> Unit,
  onBackToHome: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(DanaSuccessContainer)
      ) {
        Icon(
          imageVector = Icons.Default.Verified,
          contentDescription = null,
          tint = DanaSuccess,
          modifier = Modifier.size(48.dp)
        )
      }

      Text(
        text = "Verifikasi Kilat Berhasil!",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.Bold,
          color = DanaBluePrimary
        ),
        textAlign = TextAlign.Center
      )

      Text(
        text = "Selamat, data identitas, biometrik, dan kemitraan kampus Anda telah disetujui otomatis oleh sistem DanaCita.",
        style = MaterialTheme.typography.bodyMedium.copy(color = DanaTextSecondary),
        textAlign = TextAlign.Center
      )

      // Credit Score & Approved Limit Showcase Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.verticalGradient(
              colors = listOf(DanaBluePrimary, DanaBlueDark)
            )
          )
          .padding(20.dp)
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "Plafon Pembiayaan Aktif",
              color = Color.White.copy(alpha = 0.85f),
              fontSize = 12.sp
            )
            StatusPill(
              text = "Grade A+ (Sangat Baik)",
              color = Color(0xFF0D9488),
              backgroundColor = Color(0xFFCCFBF1)
            )
          }

          Text(
            text = formatRupiah(state.generatedLimit),
            color = Color.White,
            style = MaterialTheme.typography.displayLarge.copy(
              fontSize = 28.sp,
              fontWeight = FontWeight.Bold
            )
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(Color.White.copy(alpha = 0.12f))
              .padding(vertical = 10.dp)
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "Skor Kredit",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 11.sp
              )
              Text(
                text = "${state.generatedScore} / 1000",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
            }
            Box(
              modifier = Modifier
                .width(1.dp)
                .height(28.dp)
                .background(Color.White.copy(alpha = 0.2f))
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "Waktu Verifikasi",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 11.sp
              )
              Text(
                text = "Instan (< 1 Menit)",
                color = DanaGold,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              )
            }
          }
        }
      }

      Button(
        onClick = onApplyLoan,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("button_apply_now_after_verify")
      ) {
        Text("Ajukan Pembiayaan Kuliah Sekarang", fontWeight = FontWeight.Bold)
      }

      OutlinedButton(
        onClick = onBackToHome,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("button_back_home_after_verify")
      ) {
        Text("Kembali ke Beranda", color = DanaBluePrimary, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}
