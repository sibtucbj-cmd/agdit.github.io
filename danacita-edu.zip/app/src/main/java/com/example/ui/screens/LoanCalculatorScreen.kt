package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.OjkComplianceFooter
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun LoanCalculatorScreen(
  viewModel: LoanViewModel,
  onProceedToApply: () -> Unit,
  modifier: Modifier = Modifier
) {
  val simAmount by viewModel.simAmount.collectAsState()
  val simTenor by viewModel.simTenor.collectAsState()
  val simPurpose by viewModel.simPurpose.collectAsState()
  val scrollState = rememberScrollState()

  val calc = viewModel.getSimulationDetails()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(DanaBlueContainer)
      ) {
        Icon(
          imageVector = Icons.Default.Calculate,
          contentDescription = null,
          tint = DanaBluePrimary,
          modifier = Modifier.size(24.dp)
        )
      }
      Column {
        Text(
          text = "Simulasi Cicilan Transparan",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = DanaBluePrimary
          )
        )
        Text(
          text = "Hitung estimasi angsuran pembiayaan tanpa biaya tersembunyi",
          style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
        )
      }
    }

    // Purpose Selector Chips
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Tujuan Pembiayaan Pendidikan:",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )

        val purposes = listOf(
          "Biaya SPP / UKT Kuliah",
          "Uang Pangkal Kuliah",
          "Bootcamp IT & Coding",
          "Kursus & Sertifikasi"
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          purposes.take(2).forEach { p ->
            val isSelected = simPurpose == p
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSelected) DanaBlueContainer else Color(0xFFF1F5F9))
                .border(
                  width = 1.dp,
                  color = if (isSelected) DanaBluePrimary else DanaOutline,
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { viewModel.updateSimPurpose(p) }
                .padding(vertical = 10.dp, horizontal = 8.dp)
            ) {
              Text(
                text = p,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DanaBluePrimary else DanaTextPrimary,
                textAlign = TextAlign.Center
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          purposes.drop(2).forEach { p ->
            val isSelected = simPurpose == p
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSelected) DanaBlueContainer else Color(0xFFF1F5F9))
                .border(
                  width = 1.dp,
                  color = if (isSelected) DanaBluePrimary else DanaOutline,
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { viewModel.updateSimPurpose(p) }
                .padding(vertical = 10.dp, horizontal = 8.dp)
            ) {
              Text(
                text = p,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DanaBluePrimary else DanaTextPrimary,
                textAlign = TextAlign.Center
              )
            }
          }
        }
      }
    }

    // Amount Selection Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Nominal Pinjaman",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = formatRupiah(simAmount),
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = DanaBluePrimary
            )
          )
        }

        Slider(
          value = simAmount.toFloat(),
          onValueChange = { viewModel.updateSimAmount(it.toLong()) },
          valueRange = 2_000_000f..40_000_000f,
          steps = 37,
          colors = SliderDefaults.colors(
            thumbColor = DanaBluePrimary,
            activeTrackColor = DanaBluePrimary,
            inactiveTrackColor = Color(0xFFE2E8F0)
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("slider_loan_amount")
        )

        Row(
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Min Rp 2 Juta", style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary))
          Text("Maks Rp 40 Juta", style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary))
        }

        // Quick amount chips
        Text(
          text = "Pilihan Cepat:",
          style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary)
        )
        val quickAmounts = listOf(5_000_000L, 10_000_000L, 15_000_000L, 25_000_000L)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(quickAmounts) { amt ->
            val isSelected = simAmount == amt
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) DanaBluePrimary else Color(0xFFF1F5F9))
                .clickable { viewModel.updateSimAmount(amt) }
                .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text(
                text = formatRupiah(amt),
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else DanaTextPrimary
              )
            }
          }
        }
      }
    }

    // Tenor Selection Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Jangka Waktu (Tenor)",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )
          StatusPill(
            text = "$simTenor Bulan",
            color = DanaBluePrimary,
            backgroundColor = DanaBlueContainer
          )
        }

        val tenors = listOf(3, 6, 9, 12, 18, 24)
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          tenors.forEach { t ->
            val isSelected = simTenor == t
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSelected) DanaBluePrimary else Color(0xFFF1F5F9))
                .border(
                  width = 1.dp,
                  color = if (isSelected) DanaBluePrimary else DanaOutline,
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { viewModel.updateSimTenor(t) }
                .padding(vertical = 10.dp)
                .testTag("tenor_chip_$t")
            ) {
              Text(
                text = "${t} bln",
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else DanaTextPrimary
              )
            }
          }
        }
      }
    }

    // Calculation Result Box
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(
          Brush.verticalGradient(
            colors = listOf(DanaBluePrimary, DanaBlueDark)
          )
        )
        .padding(20.dp)
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Estimasi Cicilan per Bulan",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 13.sp
          )
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color.White.copy(alpha = 0.15f))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "Setara ${formatRupiah(calc.dailyEquivalent)} / hari",
              color = DanaGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Text(
          text = formatRupiah(calc.monthlyInstallment),
          color = Color.White,
          style = MaterialTheme.typography.displayLarge.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 32.sp
          )
        )

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color.White.copy(alpha = 0.2f))
        )

        // Rincian Breakdown
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Pokok Pinjaman", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Text(formatRupiah(calc.principal), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Biaya Platform (1.3% flat/bln)", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Text(formatRupiah(calc.totalFee), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Total Pembayaran ($simTenor Bulan)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(formatRupiah(calc.totalPayment), color = DanaGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Call to action
    Button(
      onClick = onProceedToApply,
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("button_proceed_to_apply")
    ) {
      Text(
        text = "Ajukan Sekarang dengan Simulasi Ini",
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
      )
      Spacer(modifier = Modifier.width(6.dp))
      Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
    }

    OjkComplianceFooter()
  }
}
