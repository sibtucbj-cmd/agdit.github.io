package com.example.ui.util

import java.text.NumberFormat
import java.util.Locale

fun formatRupiah(amount: Long): String {
  val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
  formatter.maximumFractionDigits = 0
  val formatted = formatter.format(amount)
  // Clean up any weird non-breaking space issues
  return formatted.replace("Rp", "Rp ").replace(",00", "")
}

fun calculateLoanDetails(
  principal: Long,
  tenorMonths: Int,
  monthlyFeeRate: Double = 0.013
): LoanCalculationResult {
  val totalFee = (principal * monthlyFeeRate * tenorMonths).toLong()
  val totalPayment = principal + totalFee
  val monthlyInstallment = totalPayment / tenorMonths
  val dailyEquivalent = monthlyInstallment / 30

  return LoanCalculationResult(
    principal = principal,
    tenorMonths = tenorMonths,
    monthlyFeeRate = monthlyFeeRate,
    totalFee = totalFee,
    totalPayment = totalPayment,
    monthlyInstallment = monthlyInstallment,
    dailyEquivalent = dailyEquivalent
  )
}

data class LoanCalculationResult(
  val principal: Long,
  val tenorMonths: Int,
  val monthlyFeeRate: Double,
  val totalFee: Long,
  val totalPayment: Long,
  val monthlyInstallment: Long,
  val dailyEquivalent: Long
)
