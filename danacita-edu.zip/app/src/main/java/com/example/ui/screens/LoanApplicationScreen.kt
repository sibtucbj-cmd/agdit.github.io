package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartnerData
import com.example.data.model.PartnerInstitution
import com.example.data.model.VerificationStatus
import com.example.ui.components.OjkComplianceFooter
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.calculateLoanDetails
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun LoanApplicationScreen(
  viewModel: LoanViewModel,
  onNavigateBack: () -> Unit,
  onSuccessSubmitted: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val selectedPartner by viewModel.selectedPartner.collectAsState()
  val simAmount by viewModel.simAmount.collectAsState()
  val simTenor by viewModel.simTenor.collectAsState()
  val simPurpose by viewModel.simPurpose.collectAsState()

  var chosenPartner by remember { mutableStateOf(selectedPartner ?: PartnerData.partners.first()) }
  var chosenPurpose by remember { mutableStateOf(simPurpose) }
  var amountInput by remember { mutableStateOf(simAmount.toString()) }
  var chosenTenor by remember { mutableIntStateOf(simTenor) }
  var studentIdNumber by remember { mutableStateOf(userProfile?.studentId ?: "2006123456") }
  var agreedToTerms by remember { mutableStateOf(true) }

  val scrollState = rememberScrollState()

  BackHandler {
    onNavigateBack()
  }

  val parsedAmount = amountInput.toLongOrNull() ?: simAmount
  val calc = calculateLoanDetails(parsedAmount, chosenTenor)
  val isVerified = userProfile?.verificationStatus == VerificationStatus.VERIFIED.name

  Scaffold(
    topBar = {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("apply_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Kembali",
              tint = DanaBluePrimary
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Pengajuan Pembiayaan",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
            Text(
              text = "Pencairan langsung ke rekening institusi pendidikan",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
          }
        }
      }
    },
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Verification Status Card
      if (!isVerified) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(14.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Speed,
              contentDescription = null,
              tint = Color(0xFFD97706),
              modifier = Modifier.size(24.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Verifikasi Cepat Diperlukan",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF92400E)
                )
              )
              Text(
                text = "Lakukan verifikasi KTP dan wajah kilat sebelum mengajukan pencairan pembiayaan.",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFB45309))
              )
            }
          }
        }
      }

      // Registered Borrower Info
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DanaBlueContainer),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.padding(12.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = null,
              tint = DanaBluePrimary,
              modifier = Modifier.size(20.dp)
            )
            Column {
              Text(
                text = "Peminjam: ${userProfile?.fullName ?: "Budi Santoso"}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = DanaBluePrimary)
              )
              Text(
                text = "Peran: ${userProfile?.borrowerRole ?: "Mahasiswa"} • ${userProfile?.phoneNumber ?: "081234567890"}",
                style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary, fontSize = 11.sp)
              )
            }
          }

          Text(
            text = "Daftar Baru",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = DanaBluePrimary,
            modifier = Modifier
              .clickable { viewModel.navigateTo(Screen.Register) }
              .padding(4.dp)
              .testTag("apply_switch_register_borrower")
          )
        }
      }

      // Partner Selection Card
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(imageVector = Icons.Default.School, contentDescription = null, tint = DanaBluePrimary)
            Text(
              text = "Institusi / Kampus Penerima Dana",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
          }

          val availablePartners = PartnerData.partners.take(4)
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            availablePartners.forEach { p ->
              val isSelected = chosenPartner.id == p.id
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) DanaBlueContainer else Color(0xFFF8FAFC))
                  .border(
                    width = 1.dp,
                    color = if (isSelected) DanaBluePrimary else DanaOutline,
                    shape = RoundedCornerShape(10.dp)
                  )
                  .clickable { chosenPartner = p }
                  .padding(12.dp)
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column {
                    Text(
                      text = p.name,
                      style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) DanaBluePrimary else DanaTextPrimary
                      )
                    )
                    Text(
                      text = p.programs,
                      style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
                    )
                  }
                  if (isSelected) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = DanaBluePrimary,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }
          }

          OutlinedTextField(
            value = studentIdNumber,
            onValueChange = { studentIdNumber = it },
            label = { Text("Nomor Tagihan / NIM Mahasiswa") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = DanaBluePrimary,
              unfocusedBorderColor = DanaOutline
            )
          )
        }
      }

      // Loan Amount & Tenor Form
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Text(
            text = "Nominal & Jangka Waktu Pembiayaan",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )

          OutlinedTextField(
            value = amountInput,
            onValueChange = { amountInput = it.filter { ch -> ch.isDigit() } },
            label = { Text("Nominal Pinjaman (Rupiah)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("apply_amount_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = DanaBluePrimary,
              unfocusedBorderColor = DanaOutline
            )
          )

          Text(
            text = "Pilih Tenor Pembayaran:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
          )

          val tenors = listOf(3, 6, 9, 12, 18, 24)
          Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            tenors.forEach { t ->
              val isSelected = chosenTenor == t
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSelected) DanaBluePrimary else Color(0xFFF1F5F9))
                  .clickable { chosenTenor = t }
                  .padding(vertical = 10.dp)
              ) {
                Text(
                  text = "${t} bln",
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else DanaTextPrimary
                )
              }
            }
          }
        }
      }

      // Summary Card
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(
            Brush.verticalGradient(
              colors = listOf(DanaBluePrimary, DanaBlueDark)
            )
          )
          .padding(18.dp)
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Ringkasan Pembiayaan Pendidikan",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )

          Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Penerima Dana", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(chosenPartner.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          }

          Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Pokok Pembiayaan", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(formatRupiah(calc.principal), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          }

          Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Biaya Platform Transparan (1.3%)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(formatRupiah(calc.totalFee), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          }

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(1.dp)
              .background(Color.White.copy(alpha = 0.2f))
          )

          Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Angsuran per Bulan ($chosenTenor Bulan)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(formatRupiah(calc.monthlyInstallment), color = DanaGold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          }
        }
      }

      // Terms & Conditions Checkbox
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .fillMaxWidth()
          .clickable { agreedToTerms = !agreedToTerms }
      ) {
        Checkbox(
          checked = agreedToTerms,
          onCheckedChange = { agreedToTerms = it },
          colors = CheckboxDefaults.colors(checkedColor = DanaBluePrimary),
          modifier = Modifier.testTag("apply_checkbox_terms")
        )
        Text(
          text = "Saya menyetujui Perjanjian Penyaluran Pembiayaan (SP3K) DanaCita dan mengizinkan pencairan langsung ke institusi pendidikan.",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = DanaTextSecondary)
        )
      }

      // Submit Button
      Button(
        onClick = {
          viewModel.submitLoanApplication(
            purpose = chosenPurpose,
            institution = chosenPartner.name,
            amount = calc.principal,
            tenor = chosenTenor,
            onSuccess = onSuccessSubmitted
          )
        },
        enabled = agreedToTerms && calc.principal > 0,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("apply_submit_button")
      ) {
        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Konfirmasi & Ajukan Pembiayaan", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }

      OjkComplianceFooter()
    }
  }
}
