package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BillStatus
import com.example.data.model.InstallmentBill
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillsScreen(
  viewModel: LoanViewModel,
  modifier: Modifier = Modifier
) {
  val allBills by viewModel.allBills.collectAsState()
  val unpaidBills by viewModel.unpaidBills.collectAsState()
  val selectedBillForPayment by viewModel.selectedBillForPayment.collectAsState()

  var selectedTabIndex by remember { mutableIntStateOf(0) }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()

  val displayedBills = if (selectedTabIndex == 0) {
    unpaidBills
  } else {
    allBills.filter { it.status == BillStatus.PAID.name }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(DanaBlueContainer)
      ) {
        Icon(
          imageVector = Icons.Default.CreditCard,
          contentDescription = null,
          tint = DanaBluePrimary,
          modifier = Modifier.size(24.dp)
        )
      }
      Column {
        Text(
          text = "Jadwal & Riwayat Tagihan",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = DanaBluePrimary
          )
        )
        Text(
          text = "Kelola cicilan pembiayaan kuliah & riwayat pembayaran",
          style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
        )
      }
    }

    // Tabs: Belum Bayar vs Riwayat Lunas
    TabRow(
      selectedTabIndex = selectedTabIndex,
      containerColor = Color.Transparent,
      contentColor = DanaBluePrimary,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
          color = DanaBluePrimary
        )
      }
    ) {
      Tab(
        selected = selectedTabIndex == 0,
        onClick = { selectedTabIndex = 0 },
        text = {
          Text(
            text = "Belum Dibayar (${unpaidBills.size})",
            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp
          )
        },
        modifier = Modifier.testTag("tab_unpaid_bills")
      )
      Tab(
        selected = selectedTabIndex == 1,
        onClick = { selectedTabIndex = 1 },
        text = {
          Text(
            text = "Riwayat Lunas",
            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp
          )
        },
        modifier = Modifier.testTag("tab_paid_bills")
      )
    }

    if (displayedBills.isEmpty()) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = DanaSuccess,
            modifier = Modifier.size(48.dp)
          )
          Text(
            text = if (selectedTabIndex == 0) "Tidak Ada Tagihan Aktif" else "Belum Ada Riwayat Pembayaran",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = if (selectedTabIndex == 0) "Semua cicilan pembiayaan Anda telah lunas." else "Pembayaran cicilan akan tercatat di sini.",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.weight(1f)
      ) {
        items(displayedBills, key = { it.id }) { bill ->
          BillCard(
            bill = bill,
            onPayClick = { viewModel.selectBillForPayment(bill) }
          )
        }
      }
    }
  }

  // Payment Bottom Sheet
  if (selectedBillForPayment != null) {
    val bill = selectedBillForPayment!!
    var selectedMethod by remember { mutableStateOf("BCA Virtual Account") }

    ModalBottomSheet(
      onDismissRequest = { viewModel.selectBillForPayment(null) },
      sheetState = sheetState,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Pembayaran Cicilan Kuliah",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          IconButton(onClick = { viewModel.selectBillForPayment(null) }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
          }
        }

        // Bill Summary Box
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = DanaBlueContainer),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = bill.loanPurpose,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = DanaBluePrimary)
            )
            Text(
              text = "${bill.institutionName} • Cicilan ke-${bill.billNumber} dari ${bill.totalBills}",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Total Tagihan:", fontSize = 12.sp, color = DanaTextSecondary)
              Text(
                text = formatRupiah(bill.amount),
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = DanaBluePrimary
                )
              )
            }
          }
        }

        Text(
          text = "Pilih Metode Pembayaran:",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
        )

        val methods = listOf(
          Pair("BCA Virtual Account", Icons.Default.AccountBalance),
          Pair("Mandiri Virtual Account", Icons.Default.AccountBalance),
          Pair("BRI Virtual Account", Icons.Default.AccountBalance),
          Pair("QRIS (GoPay, OVO, ShopeePay)", Icons.Default.QrCode2)
        )

        methods.forEach { (methodName, icon) ->
          val isSelected = selectedMethod == methodName
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) DanaBlueContainer else Color(0xFFF8FAFC)
            ),
            border = BorderStroke(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) DanaBluePrimary else DanaOutline
            ),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { selectedMethod = methodName }
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.padding(12.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Icon(
                  imageVector = icon,
                  contentDescription = null,
                  tint = if (isSelected) DanaBluePrimary else DanaTextSecondary
                )
                Text(
                  text = methodName,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) DanaBluePrimary else DanaTextPrimary
                  )
                )
              }
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = DanaBluePrimary,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }

        // Virtual Account Details Box
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(12.dp)
          ) {
            Column {
              Text("Nomor Virtual Account:", fontSize = 11.sp, color = DanaTextSecondary)
              Text(
                text = bill.virtualAccount,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            StatusPill(
              text = "Salin Nomor",
              color = DanaBluePrimary,
              backgroundColor = DanaBlueContainer,
              icon = Icons.Default.ContentCopy
            )
          }
        }

        Button(
          onClick = {
            scope.launch {
              sheetState.hide()
              viewModel.payBill(bill.id, selectedMethod)
            }
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("confirm_pay_bill_button")
        ) {
          Text("Bayar Sekarang (${formatRupiah(bill.amount)})", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}

@Composable
fun BillCard(
  bill: InstallmentBill,
  onPayClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isPaid = bill.status == BillStatus.PAID.name

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, if (isPaid) Color(0xFFBBF7D0) else DanaOutline),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(if (isPaid) DanaSuccessContainer else Color(0xFFFEF3C7))
          ) {
            Icon(
              imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.Receipt,
              contentDescription = null,
              tint = if (isPaid) DanaSuccess else DanaGold,
              modifier = Modifier.size(18.dp)
            )
          }

          Column {
            Text(
              text = bill.loanPurpose,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "${bill.institutionName} • Cicilan ke-${bill.billNumber}/${bill.totalBills}",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
          }
        }

        if (isPaid) {
          StatusPill(
            text = "Lunas",
            color = DanaSuccess,
            backgroundColor = DanaSuccessContainer,
            icon = Icons.Default.CheckCircle
          )
        } else {
          StatusPill(
            text = "Jatuh Tempo: ${bill.dueDate}",
            color = Color(0xFFD97706),
            backgroundColor = Color(0xFFFEF3C7)
          )
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Text(
            text = "Nominal Tagihan",
            style = MaterialTheme.typography.labelSmall.copy(color = DanaTextSecondary)
          )
          Text(
            text = formatRupiah(bill.amount),
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = DanaBluePrimary
            )
          )
        }

        if (!isPaid) {
          Button(
            onClick = onPayClick,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
            modifier = Modifier.testTag("pay_bill_btn_${bill.id}")
          ) {
            Text("Bayar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        } else {
          Text(
            text = "Dibayar via ${bill.paymentMethod ?: "BCA VA"}",
            style = MaterialTheme.typography.labelSmall.copy(color = DanaSuccess, fontWeight = FontWeight.SemiBold)
          )
        }
      }
    }
  }
}
