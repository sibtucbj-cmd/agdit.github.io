package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VerificationStatus
import com.example.ui.components.OjkComplianceFooter
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun ProfileScreen(
  viewModel: LoanViewModel,
  onNavigateToScreen: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val scrollState = rememberScrollState()

  val isVerified = userProfile?.verificationStatus == VerificationStatus.VERIFIED.name
  val profile = userProfile

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Avatar & Name Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.padding(16.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(DanaBlueContainer)
        ) {
          Icon(
            imageVector = Icons.Default.Person,
            contentDescription = null,
            tint = DanaBluePrimary,
            modifier = Modifier.size(32.dp)
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = profile?.fullName ?: "Budi Santoso",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = profile?.universityName ?: "Universitas Indonesia",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
          )
          Text(
            text = profile?.major ?: "Teknik Informatika",
            style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary, fontSize = 11.sp)
          )
        }

        if (isVerified) {
          StatusPill(
            text = "Terverifikasi",
            color = DanaSuccess,
            backgroundColor = DanaSuccessContainer,
            icon = Icons.Default.Verified
          )
        } else {
          Button(
            onClick = { onNavigateToScreen(Screen.FastVerification) },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary)
          ) {
            Text("Verifikasi", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Credit & Limit Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, DanaOutline),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
          text = "Status Penilaian Finansial DanaCita",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )

        Row(
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column {
            Text("Skor Kelayakan Kredit", fontSize = 11.sp, color = DanaTextSecondary)
            Text(
              text = if (isVerified) "${profile?.creditScore ?: 825} / 1000" else "Belum Dihitung",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isVerified) DanaSuccess else DanaTextSecondary
              )
            )
          }
          Column(horizontalAlignment = Alignment.End) {
            Text("Plafon Pembiayaan", fontSize = 11.sp, color = DanaTextSecondary)
            Text(
              text = if (isVerified) formatRupiah(profile?.approvedLimit ?: 35_000_000L) else "Rp 0",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
          }
        }

        // Demo test action: Reset or Run verification again
        OutlinedButton(
          onClick = {
            if (isVerified) {
              viewModel.resetVerificationForDemo()
            }
            onNavigateToScreen(Screen.FastVerification)
          },
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("button_test_fast_verify_again")
        ) {
          Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isVerified) "Tes Ulang Proses Verifikasi Cepat (Demo)" else "Mulai Verifikasi Cepat Sekarang",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }

        OutlinedButton(
          onClick = {
            viewModel.resetRegistrationForm()
            onNavigateToScreen(Screen.Register)
          },
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("button_register_new_borrower_profile")
        ) {
          Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Pendaftaran Calon Peminjam Baru",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    // Identity & Bank Details
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, DanaOutline),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Informasi Terdaftar",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )

        DetailRow(label = "Nomor KTP (NIK)", value = profile?.nik ?: "3201123456780001")
        DetailRow(label = "NIM Mahasiswa", value = profile?.studentId ?: "2006123456")
        DetailRow(label = "Rekening Pencairan", value = "${profile?.bankName ?: "BCA"} - ${profile?.bankAccountNumber ?: "5271928371"}")
        DetailRow(label = "Penjamin / Orang Tua", value = "${profile?.emergencyContactName ?: "Agus Santoso"} (${profile?.emergencyContactRelation ?: "Ayah"})")
        DetailRow(label = "Kontak Penjamin", value = profile?.emergencyContactPhone ?: "081398765432")
      }
    }

    // Help Center & Support Contact
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, DanaOutline),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Help,
            contentDescription = null,
            tint = DanaBluePrimary
          )
          Text(
            text = "Pusat Bantuan & Layanan Konsumen",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column {
            Text("Call Center DanaCita", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
            Text("021 - 5085 8788 (Senin - Jumat 09:00 - 18:00)", style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary))
          }
          Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = DanaBluePrimary)
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column {
            Text("WhatsApp Resmi DanaCita", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
            Text("+62 811-2234-5678 (Chat Bantuan Cepat)", style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary))
          }
          Icon(imageVector = Icons.Default.ContactPhone, contentDescription = null, tint = DanaSuccess)
        }
      }
    }

    OjkComplianceFooter()
  }
}

@Composable
fun DetailRow(label: String, value: String) {
  Row(
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier.fillMaxWidth()
  ) {
    Text(label, color = DanaTextSecondary, fontSize = 12.sp)
    Text(value, color = DanaTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
  }
}
