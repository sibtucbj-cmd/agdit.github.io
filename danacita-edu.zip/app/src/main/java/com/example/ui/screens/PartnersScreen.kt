package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartnerData
import com.example.data.model.PartnerInstitution
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun PartnersScreen(
  viewModel: LoanViewModel,
  onSelectPartner: (PartnerInstitution) -> Unit,
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Semua") }

  val categories = listOf("Semua", "Universitas", "Bootcamp IT", "Kursus Bahasa")

  val filteredPartners = PartnerData.partners.filter { partner ->
    val matchesCategory = selectedCategory == "Semua" || partner.category == selectedCategory
    val matchesSearch = partner.name.contains(searchQuery, ignoreCase = true) ||
      partner.programs.contains(searchQuery, ignoreCase = true) ||
      partner.location.contains(searchQuery, ignoreCase = true)
    matchesCategory && matchesSearch
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(DanaBlueContainer)
      ) {
        Icon(
          imageVector = Icons.Default.AccountBalance,
          contentDescription = null,
          tint = DanaBluePrimary,
          modifier = Modifier.size(24.dp)
        )
      }
      Column {
        Text(
          text = "Mitra Pendidikan Resmi",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = DanaBluePrimary
          )
        )
        Text(
          text = "Kampus PTN/PTS, Bootcamp Coding & Kursus Bersertifikat",
          style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
        )
      }
    }

    // Search bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Cari universitas, jurusan, atau bootcamp...") },
      leadingIcon = {
        Icon(imageVector = Icons.Default.Search, contentDescription = "Cari", tint = DanaTextSecondary)
      },
      singleLine = true,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("search_partners_input"),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = DanaBluePrimary,
        unfocusedBorderColor = DanaOutline
      ),
      shape = RoundedCornerShape(12.dp)
    )

    // Category filter chips
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(categories) { cat ->
        val isSelected = selectedCategory == cat
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) DanaBluePrimary else Color(0xFFF1F5F9))
            .clickable { selectedCategory = cat }
            .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
          Text(
            text = cat,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else DanaTextPrimary
          )
        }
      }
    }

    // Partner List
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.weight(1f)
    ) {
      items(filteredPartners, key = { it.id }) { partner ->
        PartnerItemCard(
          partner = partner,
          onApplyClick = {
            viewModel.selectPartner(partner)
            onSelectPartner(partner)
          }
        )
      }
    }
  }
}

@Composable
fun PartnerItemCard(
  partner: PartnerInstitution,
  onApplyClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, DanaOutline),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(partner.colorHex).copy(alpha = 0.15f))
          ) {
            Text(
              text = partner.name.take(2).uppercase(),
              color = Color(partner.colorHex),
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
          }

          Column {
            Text(
              text = partner.name,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = DanaTextSecondary,
                modifier = Modifier.size(13.dp)
              )
              Text(
                text = partner.location,
                style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary, fontSize = 11.sp)
              )
            }
          }
        }

        StatusPill(
          text = partner.badgeText,
          color = DanaBluePrimary,
          backgroundColor = DanaBlueContainer
        )
      }

      Text(
        text = "Program yang didukung: ${partner.programs}",
        style = MaterialTheme.typography.bodySmall.copy(color = DanaTextPrimary)
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Text(
            text = "Tenor s/d ${partner.maxTenorMonths} Bulan",
            style = MaterialTheme.typography.labelSmall.copy(
              color = DanaSuccess,
              fontWeight = FontWeight.Bold
            )
          )
          Text(
            text = partner.feeDescription,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = DanaTextSecondary)
          )
        }

        Button(
          onClick = onApplyClick,
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
          modifier = Modifier.testTag("apply_partner_${partner.id}")
        ) {
          Text("Ajukan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.width(4.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }
  }
}
