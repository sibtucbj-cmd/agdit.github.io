package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartnerData
import com.example.ui.components.OjkComplianceFooter
import com.example.ui.components.StatusPill
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.viewmodel.LoanViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun RegistrationScreen(
  viewModel: LoanViewModel,
  onNavigateBack: () -> Unit,
  onProceedToVerification: () -> Unit,
  onProceedToLoanApply: () -> Unit,
  modifier: Modifier = Modifier
) {
  val state by viewModel.registrationState.collectAsState()
  val scrollState = rememberScrollState()

  BackHandler {
    onNavigateBack()
  }

  Scaffold(
    topBar = {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("reg_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Kembali",
              tint = DanaBluePrimary
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Pendaftaran Calon Peminjam",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
            Text(
              text = "Buka akun pembiayaan pendidikan resmi & berizin OJK",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )
          }

          StatusPill(
            text = "Gratis 100%",
            color = DanaSuccess,
            backgroundColor = DanaSuccessContainer
          )
        }
      }
    },
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (state.isRegisteredSuccess) {
        // SUCCESS STATE CARD
        RegistrationSuccessCard(
          state = state,
          onProceedToVerification = onProceedToVerification,
          onProceedToLoanApply = onProceedToLoanApply
        )
      } else {
        // FORM REGISTRASI
        RegistrationFormCard(
          state = state,
          viewModel = viewModel
        )
      }

      OjkComplianceFooter()
    }
  }
}

@Composable
fun RegistrationFormCard(
  state: com.example.ui.viewmodel.RegistrationFormState,
  viewModel: LoanViewModel
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Role Selection
      Text(
        text = "Saya Mendaftar Sebagai:",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )

      val roles = listOf(
        Pair("Mahasiswa", "Pelajar S1/S2/D3"),
        Pair("Siswa Bootcamp", "Kursus / Karir IT"),
        Pair("Orang Tua / Wali", "Penjamin Siswa")
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        roles.forEach { (roleName, roleDesc) ->
          val isSelected = state.role == roleName
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSelected) DanaBlueContainer else Color(0xFFF8FAFC))
              .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) DanaBluePrimary else DanaOutline,
                shape = RoundedCornerShape(10.dp)
              )
              .clickable { viewModel.updateRegistrationRole(roleName) }
              .padding(vertical = 10.dp, horizontal = 4.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = roleName,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DanaBluePrimary else DanaTextPrimary,
                textAlign = TextAlign.Center
              )
              Text(
                text = roleDesc,
                fontSize = 9.sp,
                color = DanaTextSecondary,
                textAlign = TextAlign.Center
              )
            }
          }
        }
      }

      // Input Fields
      OutlinedTextField(
        value = state.fullName,
        onValueChange = { viewModel.updateRegistrationField(fullName = it) },
        label = { Text("Nama Lengkap Sesuai KTP") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = DanaBluePrimary)
        },
        placeholder = { Text("misal: Siti Nurhaliza") },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reg_input_name"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.phoneNumber,
        onValueChange = { viewModel.updateRegistrationField(phoneNumber = it) },
        label = { Text("Nomor WhatsApp Aktif") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = DanaBluePrimary)
        },
        placeholder = { Text("misal: 081234567890") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reg_input_phone"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.email,
        onValueChange = { viewModel.updateRegistrationField(email = it) },
        label = { Text("Alamat Email Aktif") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = DanaBluePrimary)
        },
        placeholder = { Text("siti@mahasiswa.ac.id") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reg_input_email"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      OutlinedTextField(
        value = state.passwordPin,
        onValueChange = {
          if (it.length <= 6) {
            viewModel.updateRegistrationField(passwordPin = it)
          }
        },
        label = { Text("PIN Keamanan Akun (6 Digit Angka)") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = DanaBluePrimary)
        },
        placeholder = { Text("6 digit angka rahasia") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = PasswordVisualTransformation(),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reg_input_pin"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      // Campus destination
      Text(
        text = "Pilih Kampus / Institusi Tujuan:",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      val partnerOptions = listOf(
        "Universitas Indonesia (UI)",
        "Institut Teknologi Bandung (ITB)",
        "Hacktiv8 Coding Bootcamp",
        "BINUS University",
        "Purwadhika Digital School"
      )

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        partnerOptions.take(3).forEach { option ->
          val isSelected = state.targetCampus == option
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) DanaBlueContainer else Color(0xFFF8FAFC))
              .border(
                width = 1.dp,
                color = if (isSelected) DanaBluePrimary else DanaOutline,
                shape = RoundedCornerShape(8.dp)
              )
              .clickable { viewModel.updateRegistrationField(targetCampus = option) }
              .padding(horizontal = 12.dp, vertical = 8.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = option,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) DanaBluePrimary else DanaTextPrimary
              )
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = null,
                  tint = DanaBluePrimary,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }
        }
      }

      OutlinedTextField(
        value = state.referralCode,
        onValueChange = { viewModel.updateRegistrationField(referralCode = it.uppercase()) },
        label = { Text("Kode Promo / Referral Beasiswa (Opsional)") },
        placeholder = { Text("BEASISWAKAMPUS") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = DanaGold)
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DanaBluePrimary,
          unfocusedBorderColor = DanaOutline
        )
      )

      // OTP Section
      if (!state.isOtpSent) {
        Button(
          onClick = { viewModel.sendRegistrationOtp() },
          enabled = state.fullName.isNotBlank() && state.phoneNumber.isNotBlank() && !state.isLoading,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("reg_send_otp_button")
        ) {
          if (state.isLoading) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Mengirim OTP...")
          } else {
            Icon(imageVector = Icons.Default.Phone, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kirim Kode OTP WhatsApp", fontWeight = FontWeight.Bold)
          }
        }
      } else {
        // OTP Input Box
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
          border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "Masukkan Kode OTP WhatsApp",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = DanaBluePrimary
                )
              )
              StatusPill(
                text = "OTP Terkirim",
                color = DanaSuccess,
                backgroundColor = DanaSuccessContainer
              )
            }

            Text(
              text = "Kode verifikasi 4-digit telah dikirimkan ke ${state.phoneNumber}. Kode demo: 8492",
              style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
            )

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              OutlinedTextField(
                value = state.otpCode,
                onValueChange = { if (it.length <= 4) viewModel.updateOtpCode(it) },
                label = { Text("Kode OTP") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier
                  .weight(1f)
                  .testTag("reg_input_otp"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = DanaBluePrimary,
                  unfocusedBorderColor = DanaOutline
                )
              )

              OutlinedButton(
                onClick = { viewModel.autoFillOtp() },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("reg_autofill_otp")
              ) {
                Text("Isi (8492)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            // Agreement Checkbox
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.updateRegistrationField(agreedToTerms = !state.agreedToTerms) }
            ) {
              Checkbox(
                checked = state.agreedToTerms,
                onCheckedChange = { viewModel.updateRegistrationField(agreedToTerms = it) },
                colors = CheckboxDefaults.colors(checkedColor = DanaBluePrimary)
              )
              Text(
                text = "Saya menyetujui Ketentuan Pengguna DanaCita dan menjamin kebenaran data pendaftaran.",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = DanaTextSecondary)
              )
            }

            Button(
              onClick = { viewModel.submitRegistration {} },
              enabled = state.otpCode.length == 4 && state.agreedToTerms && !state.isLoading,
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = DanaSuccess),
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("reg_confirm_button")
            ) {
              if (state.isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Mendaftarkan Akun...")
              } else {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Selesaikan Pendaftaran Akun", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun RegistrationSuccessCard(
  state: com.example.ui.viewmodel.RegistrationFormState,
  onProceedToVerification: () -> Unit,
  onProceedToLoanApply: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(22.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(DanaSuccessContainer)
      ) {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = null,
          tint = DanaSuccess,
          modifier = Modifier.size(44.dp)
        )
      }

      Text(
        text = "Pendaftaran Berhasil!",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.Bold,
          color = DanaBluePrimary
        ),
        textAlign = TextAlign.Center
      )

      Text(
        text = "Selamat, akun peminjam atas nama ${state.fullName} telah terdaftar dan siap mengajukan pembiayaan pendidikan.",
        style = MaterialTheme.typography.bodyMedium.copy(color = DanaTextSecondary),
        textAlign = TextAlign.Center
      )

      // Borrower ID & Welcome Reward Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(
            Brush.verticalGradient(
              colors = listOf(DanaBluePrimary, DanaBlueDark)
            )
          )
          .padding(16.dp)
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("ID Peminjam Terdaftar", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            StatusPill(
              text = "Akun Aktif",
              color = Color(0xFF10B981),
              backgroundColor = Color(0xFFD1FAE5)
            )
          }

          Text(
            text = state.registeredUserId,
            color = Color.White,
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          )

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(1.dp)
              .background(Color.White.copy(alpha = 0.2f))
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CardGiftcard,
              contentDescription = null,
              tint = DanaGold,
              modifier = Modifier.size(18.dp)
            )
            Text(
              text = "Bonus Peminjam Baru: Bebas Biaya Layanan Bulan Ke-1",
              color = DanaGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "Langkah Berikutnya:",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.fillMaxWidth()
      )

      Button(
        onClick = onProceedToVerification,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DanaBluePrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("reg_next_to_verify")
      ) {
        Icon(imageVector = Icons.Default.Speed, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Lanjut ke Verifikasi Kilat (KYC)", fontWeight = FontWeight.Bold)
      }

      OutlinedButton(
        onClick = onProceedToLoanApply,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("reg_next_to_loan_apply")
      ) {
        Text("Langsung Ajukan Pinjaman Kuliah", color = DanaBluePrimary, fontWeight = FontWeight.Bold)
      }
    }
  }
}
