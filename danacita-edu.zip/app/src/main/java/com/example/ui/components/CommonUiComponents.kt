package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DanaBlueContainer
import com.example.ui.theme.DanaBlueDark
import com.example.ui.theme.DanaBluePrimary
import com.example.ui.theme.DanaGold
import com.example.ui.theme.DanaOutline
import com.example.ui.theme.DanaSuccess
import com.example.ui.theme.DanaSuccessContainer
import com.example.ui.theme.DanaTextPrimary
import com.example.ui.theme.DanaTextSecondary
import com.example.ui.viewmodel.Screen

@Composable
fun DanaCitaTopBar(
  currentScreen: Screen,
  onProfileClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    shadowElevation = 1.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
              Brush.linearGradient(
                colors = listOf(DanaBluePrimary, Color(0xFF1E6FBA))
              )
            )
        ) {
          Icon(
            imageVector = Icons.Default.School,
            contentDescription = "Logo DanaCita",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }

        Column {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = "DanaCita",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = DanaBluePrimary
              )
            )
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF0284C7))
                .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
              Text(
                text = "EDU",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = "OJK",
              tint = DanaSuccess,
              modifier = Modifier.size(11.dp)
            )
            Text(
              text = "Berizin & Diawasi OJK",
              style = MaterialTheme.typography.labelSmall.copy(
                color = DanaTextSecondary,
                fontSize = 10.sp
              )
            )
          }
        }
      }

      // Profile avatar button
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(DanaBlueContainer)
          .clickable { onProfileClick() }
          .testTag("top_bar_profile_button")
      ) {
        Icon(
          imageVector = Icons.Default.Person,
          contentDescription = "Profil Akun",
          tint = DanaBluePrimary,
          modifier = Modifier.size(22.dp)
        )
      }
    }
  }
}

@Composable
fun DanaCitaBottomNavigation(
  currentScreen: Screen,
  onSelectScreen: (Screen) -> Unit,
  unpaidCount: Int = 0,
  modifier: Modifier = Modifier
) {
  NavigationBar(
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 6.dp,
    modifier = modifier.testTag("bottom_nav_bar")
  ) {
    val items = listOf(
      Triple(Screen.Home, Icons.Default.Home, "Beranda"),
      Triple(Screen.Calculator, Icons.Default.Calculate, "Simulasi"),
      Triple(Screen.Bills, Icons.Default.CreditCard, "Tagihan"),
      Triple(Screen.Partners, Icons.Default.AccountBalance, "Mitra"),
      Triple(Screen.Profile, Icons.Default.Person, "Akun")
    )

    items.forEach { (screen, icon, label) ->
      val selected = currentScreen == screen
      NavigationBarItem(
        selected = selected,
        onClick = { onSelectScreen(screen) },
        icon = {
          if (screen == Screen.Bills && unpaidCount > 0) {
            androidx.compose.material3.BadgedBox(
              badge = {
                Badge(
                  containerColor = Color(0xFFEF4444),
                  contentColor = Color.White
                ) {
                  Text(unpaidCount.toString())
                }
              }
            ) {
              Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(24.dp)
              )
            }
          } else {
            Icon(
              imageVector = icon,
              contentDescription = label,
              modifier = Modifier.size(24.dp)
            )
          }
        },
        label = {
          Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = DanaBluePrimary,
          selectedTextColor = DanaBluePrimary,
          indicatorColor = DanaBlueContainer,
          unselectedIconColor = DanaTextSecondary,
          unselectedTextColor = DanaTextSecondary
        ),
        modifier = Modifier.testTag("nav_item_${label.lowercase()}")
      )
    }
  }
}

@Composable
fun StatusPill(
  text: String,
  color: Color,
  backgroundColor: Color,
  icon: ImageVector? = null,
  modifier: Modifier = Modifier
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(backgroundColor)
      .padding(horizontal = 8.dp, vertical = 4.dp)
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = color,
        modifier = Modifier.size(13.dp)
      )
    }
    Text(
      text = text,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold
    )
  }
}

@Composable
fun OjkComplianceFooter(
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.padding(14.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(DanaSuccessContainer)
      ) {
        Icon(
          imageVector = Icons.Default.VerifiedUser,
          contentDescription = "OJK Verified",
          tint = DanaSuccess,
          modifier = Modifier.size(20.dp)
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "Platform Pembiayaan Resmi & Berizin",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "DanaCita terdaftar dan diawasi oleh OJK serta tersertifikasi ISO 27001 untuk keamanan data mahasiswa & penjamin.",
          style = MaterialTheme.typography.bodySmall.copy(color = DanaTextSecondary)
        )
      }
    }
  }
}
