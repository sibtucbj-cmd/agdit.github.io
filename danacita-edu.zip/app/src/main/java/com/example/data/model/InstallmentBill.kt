package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class BillStatus {
  UNPAID,
  PAID,
  OVERDUE
}

@Entity(tableName = "installment_bills")
data class InstallmentBill(
  @PrimaryKey val id: String,
  val loanId: String,
  val loanPurpose: String,
  val institutionName: String,
  val billNumber: Int,
  val totalBills: Int,
  val amount: Long,
  val dueDate: String,
  val status: String = BillStatus.UNPAID.name,
  val paidAt: Long? = null,
  val paymentMethod: String? = null,
  val virtualAccount: String = "8808" + (10000000..99999999).random().toString()
)
