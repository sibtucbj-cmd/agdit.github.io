package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.LoanApplication
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanDao {
  @Query("SELECT * FROM loan_applications ORDER BY createdAt DESC")
  fun getAllLoansFlow(): Flow<List<LoanApplication>>

  @Query("SELECT * FROM loan_applications WHERE id = :id LIMIT 1")
  suspend fun getLoanById(id: String): LoanApplication?

  @Query("SELECT * FROM loan_applications WHERE status IN ('APPROVED', 'DISBURSED') ORDER BY createdAt DESC")
  fun getActiveLoansFlow(): Flow<List<LoanApplication>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLoan(loan: LoanApplication)

  @Update
  suspend fun updateLoan(loan: LoanApplication)

  @Query("DELETE FROM loan_applications WHERE id = :id")
  suspend fun deleteLoanById(id: String)
}
