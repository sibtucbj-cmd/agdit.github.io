package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BillStatus
import com.example.data.model.InstallmentBill
import com.example.data.model.LoanApplication
import com.example.data.model.LoanStatus
import com.example.data.model.UserProfile
import com.example.data.model.VerificationStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [UserProfile::class, LoanApplication::class, InstallmentBill::class],
  version = 2,
  exportSchema = false
)
abstract class DanaCitaDatabase : RoomDatabase() {
  abstract fun userDao(): UserDao
  abstract fun loanDao(): LoanDao
  abstract fun installmentDao(): InstallmentDao

  companion object {
    @Volatile
    private var INSTANCE: DanaCitaDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): DanaCitaDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          DanaCitaDatabase::class.java,
          "danacita_database"
        )
          .addCallback(DanaCitaDatabaseCallback(scope))
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class DanaCitaDatabaseCallback(
    private val scope: CoroutineScope
  ) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        scope.launch(Dispatchers.IO) {
          populateInitialData(database)
        }
      }
    }

    private suspend fun populateInitialData(database: DanaCitaDatabase) {
      val userDao = database.userDao()
      val loanDao = database.loanDao()
      val installmentDao = database.installmentDao()

      // Seed initial verified user
      val initialUser = UserProfile(
        id = "primary_user",
        fullName = "Budi Santoso",
        nik = "3201123456780001",
        email = "budi.santoso@mahasiswa.ac.id",
        phoneNumber = "081234567890",
        dateOfBirth = "15 Mei 2002",
        address = "Jl. Margonda Raya No. 45, Depok",
        universityName = "Universitas Indonesia",
        major = "Teknik Informatika (S1)",
        studentId = "2006123456",
        bankName = "BCA (Bank Central Asia)",
        bankAccountNumber = "5271928371",
        bankAccountHolder = "Budi Santoso",
        emergencyContactName = "Agus Santoso (Ayah)",
        emergencyContactPhone = "081398765432",
        emergencyContactRelation = "Orang Tua / Wali",
        verificationStatus = VerificationStatus.VERIFIED.name,
        creditScore = 825,
        approvedLimit = 35_000_000L,
        availableLimit = 23_000_000L
      )
      userDao.insertOrUpdate(initialUser)

      // Seed an active loan for tuition
      val initialLoanId = "loan-ui-ukt-2026"
      val initialLoan = LoanApplication(
        id = initialLoanId,
        purpose = "Biaya SPP / UKT Semester Genap",
        institutionName = "Universitas Indonesia (UI)",
        amount = 12_000_000L,
        tenorMonths = 6,
        monthlyInstallment = 2_156_000L,
        platformFeeRate = 0.013,
        totalPayment = 12_936_000L,
        status = LoanStatus.DISBURSED.name,
        createdAt = System.currentTimeMillis() - (45L * 24 * 60 * 60 * 1000),
        disbursedAt = System.currentTimeMillis() - (44L * 24 * 60 * 60 * 1000),
        virtualAccountNumber = "8808129845610023",
        bankName = "BCA Virtual Account",
        contractNumber = "DC-UI-2026-0891"
      )
      loanDao.insertLoan(initialLoan)

      // Seed 6 monthly installments
      val bills = listOf(
        InstallmentBill(
          id = "bill-1",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 1,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Okt 2026",
          status = BillStatus.PAID.name,
          paidAt = System.currentTimeMillis() - (15L * 24 * 60 * 60 * 1000),
          paymentMethod = "BCA Virtual Account",
          virtualAccount = "8808129845610023"
        ),
        InstallmentBill(
          id = "bill-2",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 2,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Nov 2026",
          status = BillStatus.UNPAID.name,
          virtualAccount = "8808129845610023"
        ),
        InstallmentBill(
          id = "bill-3",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 3,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Des 2026",
          status = BillStatus.UNPAID.name,
          virtualAccount = "8808129845610023"
        ),
        InstallmentBill(
          id = "bill-4",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 4,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Jan 2027",
          status = BillStatus.UNPAID.name,
          virtualAccount = "8808129845610023"
        ),
        InstallmentBill(
          id = "bill-5",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 5,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Feb 2027",
          status = BillStatus.UNPAID.name,
          virtualAccount = "8808129845610023"
        ),
        InstallmentBill(
          id = "bill-6",
          loanId = initialLoanId,
          loanPurpose = "Biaya SPP / UKT Semester Genap",
          institutionName = "Universitas Indonesia (UI)",
          billNumber = 6,
          totalBills = 6,
          amount = 2_156_000L,
          dueDate = "10 Mar 2027",
          status = BillStatus.UNPAID.name,
          virtualAccount = "8808129845610023"
        )
      )
      installmentDao.insertBills(bills)
    }
  }
}
