package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LoanStatus {
  PENDING_VERIFICATION,
  APPROVED,
  DISBURSED,
  COMPLETED,
  REJECTED
}

@Entity(tableName = "loan_applications")
data class LoanApplication(
  @PrimaryKey val id: String,
  val purpose: String,
  val institutionName: String,
  val amount: Long,
  val tenorMonths: Int,
  val monthlyInstallment: Long,
  val platformFeeRate: Double = 0.013,
  val totalPayment: Long,
  val status: String = LoanStatus.DISBURSED.name,
  val createdAt: Long = System.currentTimeMillis(),
  val disbursedAt: Long? = null,
  val virtualAccountNumber: String = "8808" + (10000000..99999999).random().toString(),
  val bankName: String = "BCA Virtual Account",
  val contractNumber: String = "DC-EDU-" + (10000..99999).random()
)
