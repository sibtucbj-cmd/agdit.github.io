package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VerificationStatus {
  UNVERIFIED,
  IN_PROGRESS,
  VERIFIED
}

@Entity(tableName = "user_profile")
data class UserProfile(
  @PrimaryKey val id: String = "primary_user",
  val fullName: String = "Budi Santoso",
  val nik: String = "3201123456780001",
  val email: String = "budi.santoso@mahasiswa.ac.id",
  val phoneNumber: String = "081234567890",
  val dateOfBirth: String = "15 Mei 2002",
  val address: String = "Jl. Margonda Raya No. 45, Depok",
  val universityName: String = "Universitas Indonesia",
  val major: String = "Teknik Informatika (S1)",
  val studentId: String = "2006123456",
  val bankName: String = "BCA (Bank Central Asia)",
  val bankAccountNumber: String = "5271928371",
  val bankAccountHolder: String = "Budi Santoso",
  val emergencyContactName: String = "Agus Santoso (Ayah)",
  val emergencyContactPhone: String = "081398765432",
  val emergencyContactRelation: String = "Orang Tua / Wali",
  val borrowerRole: String = "Mahasiswa",
  val referralCode: String = "BEASISWAKAMPUS",
  val isRegistered: Boolean = true,
  val registeredAt: Long = System.currentTimeMillis(),
  val verificationStatus: String = VerificationStatus.VERIFIED.name,
  val creditScore: Int = 820,
  val approvedLimit: Long = 35_000_000L,
  val availableLimit: Long = 23_000_000L,
  val verifiedAt: Long = System.currentTimeMillis()
)
