package com.example.data.repository

import com.example.data.local.InstallmentDao
import com.example.data.local.LoanDao
import com.example.data.local.UserDao
import com.example.data.model.BillStatus
import com.example.data.model.InstallmentBill
import com.example.data.model.LoanApplication
import com.example.data.model.LoanStatus
import com.example.data.model.UserProfile
import com.example.data.model.VerificationStatus
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class LoanRepository(
  private val userDao: UserDao,
  private val loanDao: LoanDao,
  private val installmentDao: InstallmentDao
) {
  val userProfileFlow: Flow<UserProfile?> = userDao.getUserProfileFlow()
  val allLoansFlow: Flow<List<LoanApplication>> = loanDao.getAllLoansFlow()
  val activeLoansFlow: Flow<List<LoanApplication>> = loanDao.getActiveLoansFlow()
  val allBillsFlow: Flow<List<InstallmentBill>> = installmentDao.getAllBillsFlow()
  val unpaidBillsFlow: Flow<List<InstallmentBill>> = installmentDao.getUnpaidBillsFlow()

  suspend fun getUserProfile(): UserProfile? {
    return userDao.getUserProfile()
  }

  suspend fun updateUserProfile(profile: UserProfile) {
    userDao.insertOrUpdate(profile)
  }

  suspend fun registerNewBorrower(
    fullName: String,
    email: String,
    phoneNumber: String,
    borrowerRole: String,
    universityName: String,
    referralCode: String
  ): UserProfile {
    val existing = userDao.getUserProfile()
    val newProfile = UserProfile(
      id = "primary_user",
      fullName = fullName.ifBlank { "Peminjam Baru" },
      email = email.ifBlank { "peminjam@gmail.com" },
      phoneNumber = phoneNumber.ifBlank { "081234567890" },
      borrowerRole = borrowerRole,
      universityName = universityName.ifBlank { "Universitas Indonesia" },
      referralCode = referralCode,
      isRegistered = true,
      registeredAt = System.currentTimeMillis(),
      // Retain or initialize verification state
      verificationStatus = VerificationStatus.UNVERIFIED.name,
      creditScore = 0,
      approvedLimit = 0L,
      availableLimit = 0L,
      nik = existing?.nik ?: "",
      dateOfBirth = existing?.dateOfBirth ?: "01 Jan 2002",
      address = existing?.address ?: "Jl. Pendidikan No. 1, Jakarta",
      major = existing?.major ?: "Program Sarjana",
      studentId = existing?.studentId ?: "NIM-" + (100000..999999).random(),
      bankName = existing?.bankName ?: "BCA (Bank Central Asia)",
      bankAccountNumber = existing?.bankAccountNumber ?: "",
      bankAccountHolder = fullName.ifBlank { "Peminjam Baru" },
      emergencyContactName = existing?.emergencyContactName ?: "",
      emergencyContactPhone = existing?.emergencyContactPhone ?: "",
      emergencyContactRelation = existing?.emergencyContactRelation ?: "Orang Tua / Wali"
    )
    userDao.insertOrUpdate(newProfile)
    return newProfile
  }

  suspend fun completeFastVerification(
    fullName: String,
    nik: String,
    email: String,
    phone: String,
    dob: String,
    address: String,
    university: String,
    major: String,
    studentId: String,
    bankName: String,
    bankAccount: String,
    bankHolder: String,
    emergencyName: String,
    emergencyPhone: String,
    emergencyRelation: String
  ): UserProfile {
    // Generate realistic credit score between 800 - 870
    val score = (810..865).random()
    val approvedLimit = 40_000_000L
    val currentAvailable = (approvedLimit * 0.85).toLong()

    val updatedProfile = UserProfile(
      id = "primary_user",
      fullName = fullName.ifBlank { "Budi Santoso" },
      nik = nik.ifBlank { "3201123456780001" },
      email = email.ifBlank { "budi.santoso@mahasiswa.ac.id" },
      phoneNumber = phone.ifBlank { "081234567890" },
      dateOfBirth = dob.ifBlank { "15 Mei 2002" },
      address = address.ifBlank { "Jl. Margonda Raya No. 45, Depok" },
      universityName = university.ifBlank { "Universitas Indonesia" },
      major = major.ifBlank { "Teknik Informatika (S1)" },
      studentId = studentId.ifBlank { "2006123456" },
      bankName = bankName.ifBlank { "BCA (Bank Central Asia)" },
      bankAccountNumber = bankAccount.ifBlank { "5271928371" },
      bankAccountHolder = bankHolder.ifBlank { fullName.ifBlank { "Budi Santoso" } },
      emergencyContactName = emergencyName.ifBlank { "Agus Santoso" },
      emergencyContactPhone = emergencyPhone.ifBlank { "081398765432" },
      emergencyContactRelation = emergencyRelation.ifBlank { "Orang Tua / Wali" },
      verificationStatus = VerificationStatus.VERIFIED.name,
      creditScore = score,
      approvedLimit = approvedLimit,
      availableLimit = currentAvailable,
      verifiedAt = System.currentTimeMillis()
    )

    userDao.insertOrUpdate(updatedProfile)
    return updatedProfile
  }

  suspend fun submitLoanApplication(
    purpose: String,
    institutionName: String,
    amount: Long,
    tenorMonths: Int
  ): LoanApplication {
    val feeRate = 0.013 // 1.3% flat per month
    val totalInterest = (amount * feeRate * tenorMonths).toLong()
    val totalPayment = amount + totalInterest
    val monthly = totalPayment / tenorMonths

    val loanId = "loan-" + UUID.randomUUID().toString().take(8)
    val contractNo = "DC-EDU-" + (10000..99999).random()

    val newLoan = LoanApplication(
      id = loanId,
      purpose = purpose,
      institutionName = institutionName,
      amount = amount,
      tenorMonths = tenorMonths,
      monthlyInstallment = monthly,
      platformFeeRate = feeRate,
      totalPayment = totalPayment,
      status = LoanStatus.DISBURSED.name,
      createdAt = System.currentTimeMillis(),
      disbursedAt = System.currentTimeMillis(),
      virtualAccountNumber = "8808" + (10000000..99999999).random().toString(),
      bankName = "BCA Virtual Account",
      contractNumber = contractNo
    )

    loanDao.insertLoan(newLoan)

    // Generate monthly installment bills
    val calendar = Calendar.getInstance()
    val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
    val newBills = mutableListOf<InstallmentBill>()

    for (i in 1..tenorMonths) {
      calendar.add(Calendar.MONTH, 1)
      calendar.set(Calendar.DAY_OF_MONTH, 10)
      val dueDateStr = dateFormat.format(calendar.time)

      newBills.add(
        InstallmentBill(
          id = "bill-$loanId-$i",
          loanId = loanId,
          loanPurpose = purpose,
          institutionName = institutionName,
          billNumber = i,
          totalBills = tenorMonths,
          amount = monthly,
          dueDate = dueDateStr,
          status = BillStatus.UNPAID.name,
          virtualAccount = newLoan.virtualAccountNumber
        )
      )
    }

    installmentDao.insertBills(newBills)

    // Update user available limit
    val profile = userDao.getUserProfile()
    if (profile != null) {
      val newAvailable = (profile.availableLimit - amount).coerceAtLeast(0L)
      userDao.update(profile.copy(availableLimit = newAvailable))
    }

    return newLoan
  }

  suspend fun payInstallment(
    billId: String,
    paymentMethod: String
  ) {
    installmentDao.markAsPaid(
      billId = billId,
      paidAt = System.currentTimeMillis(),
      method = paymentMethod
    )

    // Check if all bills of this loan are paid, then mark loan as COMPLETED
    val bill = installmentDao.getBillById(billId)
    if (bill != null) {
      // Re-credit the available limit partially
      val profile = userDao.getUserProfile()
      if (profile != null) {
        val restored = (profile.availableLimit + (bill.amount * 0.95).toLong()).coerceAtMost(profile.approvedLimit)
        userDao.update(profile.copy(availableLimit = restored))
      }
    }
  }

  suspend fun resetVerificationForDemo() {
    val current = userDao.getUserProfile()
    if (current != null) {
      userDao.update(
        current.copy(
          verificationStatus = VerificationStatus.UNVERIFIED.name,
          creditScore = 0,
          approvedLimit = 0L,
          availableLimit = 0L
        )
      )
    }
  }
}
