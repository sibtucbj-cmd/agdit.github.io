package com.example.data.model

data class PartnerInstitution(
  val id: String,
  val name: String,
  val category: String, // "Universitas", "Bootcamp IT", "Kursus Bahasa", "Sertifikasi"
  val location: String,
  val programs: String,
  val maxTenorMonths: Int,
  val feeDescription: String,
  val badgeText: String,
  val colorHex: Long = 0xFF0F4C81
)

object PartnerData {
  val partners = listOf(
    PartnerInstitution(
      id = "ui",
      name = "Universitas Indonesia (UI)",
      category = "Universitas",
      location = "Depok & Salemba, Jakarta",
      programs = "S1 Reguler, Paralel, Magister S2 & Vokasi",
      maxTenorMonths = 24,
      feeDescription = "Cicilan SPP/BOP mulai 1.2%/bln",
      badgeText = "Mitra Resmi PTN",
      colorHex = 0xFFF59E0B
    ),
    PartnerInstitution(
      id = "itb",
      name = "Institut Teknologi Bandung (ITB)",
      category = "Universitas",
      location = "Bandung, Jawa Barat",
      programs = "Sarjana S1, Magister S2, Sekolah Pascasarjana",
      maxTenorMonths = 24,
      feeDescription = "Cicilan UKT transparan 0% DP",
      badgeText = "Mitra Unggulan",
      colorHex = 0xFF0284C7
    ),
    PartnerInstitution(
      id = "hacktiv8",
      name = "Hacktiv8 Coding Bootcamp",
      category = "Bootcamp IT",
      location = "Jakarta Selatan & Online",
      programs = "Fullstack JavaScript, Data Science, Golang",
      maxTenorMonths = 18,
      feeDescription = "Skema ISA & Cicilan Reguler",
      badgeText = "Paling Diminati",
      colorHex = 0xFF10B981
    ),
    PartnerInstitution(
      id = "binus",
      name = "BINUS University",
      category = "Universitas",
      location = "Jakarta, Tangerang, Bandung, Malang",
      programs = "Computer Science, Design, Business & Online",
      maxTenorMonths = 24,
      feeDescription = "Pembiayaan Biaya Semester & Lab",
      badgeText = "Mitra Terverifikasi",
      colorHex = 0xFFE11D48
    ),
    PartnerInstitution(
      id = "purwadhika",
      name = "Purwadhika Digital Technology School",
      category = "Bootcamp IT",
      location = "BSD City, Batam, Jakarta & Jogja",
      programs = "Software Engineering, UI/UX, Data Analytics",
      maxTenorMonths = 18,
      feeDescription = "Cicilan ringan s/d 18 bulan",
      badgeText = "Populer",
      colorHex = 0xFF8B5CF6
    ),
    PartnerInstitution(
      id = "binar",
      name = "Binar Academy",
      category = "Bootcamp IT",
      location = "Online Interactive",
      programs = "Product Management, Android, QA Engineering",
      maxTenorMonths = 12,
      feeDescription = "Mulai Rp 600rb-an per bulan",
      badgeText = "Verifikasi Kilat",
      colorHex = 0xFF0D9488
    ),
    PartnerInstitution(
      id = "ef",
      name = "English First (EF) Adults",
      category = "Kursus Bahasa",
      location = "Seluruh Kota Besar Indonesia",
      programs = "General English, Business English, IELTS Prep",
      maxTenorMonths = 12,
      feeDescription = "Cicilan paket belajar bahasa 0% DP",
      badgeText = "Sertifikasi Global",
      colorHex = 0xFFD97706
    ),
    PartnerInstitution(
      id = "revou",
      name = "RevoU Tech Academy",
      category = "Bootcamp IT",
      location = "Online Intensive",
      programs = "Digital Marketing, Product Analytics, Tech Sales",
      maxTenorMonths = 18,
      feeDescription = "Finansial terjangkau tanpa jaminan",
      badgeText = "Rekomendasi",
      colorHex = 0xFF059669
    )
  )
}
