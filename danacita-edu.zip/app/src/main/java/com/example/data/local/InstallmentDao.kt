package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.InstallmentBill
import kotlinx.coroutines.flow.Flow

@Dao
interface InstallmentDao {
  @Query("SELECT * FROM installment_bills ORDER BY dueDate ASC")
  fun getAllBillsFlow(): Flow<List<InstallmentBill>>

  @Query("SELECT * FROM installment_bills WHERE status = 'UNPAID' ORDER BY dueDate ASC")
  fun getUnpaidBillsFlow(): Flow<List<InstallmentBill>>

  @Query("SELECT * FROM installment_bills WHERE loanId = :loanId ORDER BY billNumber ASC")
  fun getBillsByLoanIdFlow(loanId: String): Flow<List<InstallmentBill>>

  @Query("SELECT * FROM installment_bills WHERE id = :id LIMIT 1")
  suspend fun getBillById(id: String): InstallmentBill?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBills(bills: List<InstallmentBill>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBill(bill: InstallmentBill)

  @Update
  suspend fun updateBill(bill: InstallmentBill)

  @Query("UPDATE installment_bills SET status = 'PAID', paidAt = :paidAt, paymentMethod = :method WHERE id = :billId")
  suspend fun markAsPaid(billId: String, paidAt: Long, method: String)
}
