package com.example

import com.example.ui.util.calculateLoanDetails
import com.example.ui.util.formatRupiah
import com.example.ui.viewmodel.RegistrationFormState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testLoanCalculationDetails() {
    val principal = 12_000_000L
    val tenorMonths = 6
    val result = calculateLoanDetails(principal, tenorMonths, 0.013)

    assertEquals(12_000_000L, result.principal)
    assertEquals(6, result.tenorMonths)
    // 12_000_000 * 0.013 * 6 = 936_000
    assertEquals(936_000L, result.totalFee)
    assertEquals(12_936_000L, result.totalPayment)
    assertEquals(2_156_000L, result.monthlyInstallment)
  }

  @Test
  fun testFormatRupiah() {
    val formatted = formatRupiah(15_000_000L)
    assertTrue(formatted.contains("15.000.000"))
  }

  @Test
  fun testRegistrationState() {
    val reg = RegistrationFormState(
      fullName = "Siti Nurhaliza",
      phoneNumber = "081234567890",
      role = "Mahasiswa",
      targetCampus = "Universitas Indonesia (UI)",
      simulatedSentOtp = "8492"
    )
    assertEquals("Siti Nurhaliza", reg.fullName)
    assertEquals("Mahasiswa", reg.role)
    assertEquals("8492", reg.simulatedSentOtp)
    assertFalse(reg.isRegisteredSuccess)
  }
}
