package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.util.calculateLoanDetails
import com.example.ui.util.formatRupiah
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("DanaCita Edu", appName)
  }

  @Test
  fun `test loan calculation transparency`() {
    val principal = 12_000_000L
    val tenorMonths = 6
    val result = calculateLoanDetails(principal, tenorMonths, 0.013)

    assertEquals(12_000_000L, result.principal)
    assertEquals(6, result.tenorMonths)
    assertTrue(result.monthlyInstallment > 0)
    assertTrue(result.totalPayment > principal)
    assertTrue(formatRupiah(principal).contains("12.000.000"))
  }
}
